@extends('admin.layouts.app')

@section('page_title', 'Edit Product')

@section('content')
<div class="container-fluid px-0">

  <!-- Validation Errors -->
  @if ($errors->any())
    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
      <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-2"></i>Please fix the following errors:</h6>
      <ul class="mb-0 ps-3">
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  @endif

  <div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
      <h5 class="mb-0 fw-bold" style="color: #061E43;">
        <i class="bi bi-pencil-square me-2 text-primary"></i>Edit Product: {{ $product->name }}
      </h5>
      <a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back to Products
      </a>
    </div>

    <div class="card-body p-4">
      <!-- Standard HTML Form (No AJAX) -->
      <form action="{{ route('admin.products.update', $product->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="row g-3">

          <!-- 1. Product Name -->
          <div class="col-md-8">
            <label class="form-label fw-bold small" for="name">Product Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name', $product->name) }}" placeholder="e.g. Power Veda Ashwagandha Gold KSM-66" required>
            @error('name')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 2. Price -->
          <div class="col-md-4">
            <label class="form-label fw-bold small" for="price">Price (₹) <span class="text-danger">*</span></label>
            <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price', $product->price) }}" placeholder="1499" required min="0">
            @error('price')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 3. Stock -->
          <div class="col-md-4">
            <label class="form-label fw-bold small" for="stock">Stock Quantity <span class="text-danger">*</span></label>
            <input type="number" class="form-control @error('stock') is-invalid @enderror" id="stock" name="stock" value="{{ old('stock', $product->stock) }}" placeholder="50" required min="0">
            @error('stock')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 4. Photo (File Upload) -->
          <div class="col-md-8">
            <label class="form-label fw-bold small" for="photo">Product Photo (Leave empty to keep current photo)</label>
            <input type="file" class="form-control @error('photo') is-invalid @enderror" id="photo" name="photo" accept="image/*">
            <div class="form-text small">Upload JPG, PNG, or WEBP image (Max 2MB).</div>
            @error('photo')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror

            @if($product->photo)
              <div class="d-flex align-items-center gap-2 mt-2">
                <span class="small text-muted">Current Photo:</span>
                <img src="{{ $product->photo_url }}" alt="Current Photo" class="rounded border" style="width: 50px; height: 50px; object-fit: cover;">
              </div>
            @endif
          </div>

          <!-- 5. Product Detail -->
          <div class="col-12">
            <label class="form-label fw-bold small" for="detail">Product Detail / Description</label>
            <textarea class="form-control @error('detail') is-invalid @enderror" id="detail" name="detail" rows="4" placeholder="Enter product description, key Ayurvedic benefits, ingredients, and usage instructions...">{{ old('detail', $product->detail) }}</textarea>
            @error('detail')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- SEO Section Divider -->
          <div class="col-12 pt-3">
            <h6 class="fw-bold border-bottom pb-2" style="color: #061E43;">
              <i class="bi bi-search me-1 text-primary"></i> SEO &amp; Social Share Metadata
            </h6>
          </div>

          <!-- 6. Meta Title -->
          <div class="col-12">
            <label class="form-label fw-bold small" for="meta_title">Meta Title</label>
            <input type="text" class="form-control @error('meta_title') is-invalid @enderror" id="meta_title" name="meta_title" value="{{ old('meta_title', $product->meta_title) }}" placeholder="e.g. Buy Organic Ashwagandha Gold | Power Veda">
            @error('meta_title')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 7. Meta Detail -->
          <div class="col-12">
            <label class="form-label fw-bold small" for="meta_detail">Meta Detail / Description</label>
            <textarea class="form-control @error('meta_detail') is-invalid @enderror" id="meta_detail" name="meta_detail" rows="2" placeholder="Brief SEO description snippet (recommended 150-160 characters)...">{{ old('meta_detail', $product->meta_detail) }}</textarea>
            @error('meta_detail')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 8. OG Image (File Upload) -->
          <div class="col-12">
            <label class="form-label fw-bold small" for="og_image">OG Image (Leave empty to keep current image)</label>
            <input type="file" class="form-control @error('og_image') is-invalid @enderror" id="og_image" name="og_image" accept="image/*">
            <div class="form-text small">Social sharing image upload for WhatsApp/Facebook preview.</div>
            @error('og_image')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror

            @if($product->og_image)
              <div class="d-flex align-items-center gap-2 mt-2">
                <span class="small text-muted">Current OG Image:</span>
                <img src="{{ $product->og_image_url }}" alt="Current OG Image" class="rounded border" style="width: 60px; height: 35px; object-fit: cover;">
              </div>
            @endif
          </div>

          <!-- Submit Buttons -->
          <div class="col-12 pt-3">
            <hr>
            <div class="d-flex justify-content-end gap-2">
              <a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary px-4">
                <i class="bi bi-check-circle me-1"></i> Update Product
              </button>
            </div>
          </div>

        </div>
      </form>
    </div>
  </div>

</div>
@endsection
