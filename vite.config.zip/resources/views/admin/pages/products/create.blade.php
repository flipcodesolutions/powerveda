@extends('admin.layouts.app')

@section('page_title', 'Add New Product')

@section('content')
<div class="container-fluid px-0">

  <!-- Validation Errors -->
  @if ($errors->any())
    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
      <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-2"></i>Please fix the following errors:</h6>
      <ul class="mb-0 ps-3">
        @foreach ($errors->all() as $error)
          <li>{{ $error }}</li>
        @endforeach
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  @endif

  <div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
      <h5 class="mb-0 fw-bold" style="color: #061E43;">
        <i class="bi bi-plus-circle me-2 text-primary"></i>Create New Product
      </h5>
      <a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back to Products
      </a>
    </div>

    <div class="card-body p-4">
      <!-- Standard HTML Form -->
      <form action="{{ route('admin.products.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <div class="row g-3">

          <!-- 1. Product Name -->
          <div class="col-md-8">
            <label class="form-label fw-bold small" for="name">Product Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name') }}" placeholder="e.g. Power Veda Ashwagandha Gold KSM-66" required>
            @error('name')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 2. Price -->
          <div class="col-md-4">
            <label class="form-label fw-bold small" for="price">Price (₹) <span class="text-danger">*</span></label>
            <input type="number" step="0.01" class="form-control @error('price') is-invalid @enderror" id="price" name="price" value="{{ old('price') }}" placeholder="1499" required min="0">
            @error('price')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 3. Stock -->
          <div class="col-md-4">
            <label class="form-label fw-bold small" for="stock">Stock Quantity <span class="text-danger">*</span></label>
            <input type="number" class="form-control @error('stock') is-invalid @enderror" id="stock" name="stock" value="{{ old('stock', 50) }}" placeholder="50" required min="0">
            @error('stock')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 4. Photo (File Upload) -->
          <div class="col-md-8">
            <label class="form-label fw-bold small" for="photo">Product Photo (File Upload)</label>
            <input type="file" class="form-control @error('photo') is-invalid @enderror" id="photo" name="photo" accept="image/*">
            <div class="form-text small">Upload JPG, PNG, or WEBP image (Max 2MB).</div>
            @error('photo')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 5. Product Detail -->
          <div class="col-12">
            <label class="form-label fw-bold small" for="detail">Product Detail / Description</label>
            <textarea class="form-control @error('detail') is-invalid @enderror" id="detail" name="detail" rows="4" placeholder="Enter product description, key Ayurvedic benefits, ingredients, and usage instructions...">{{ old('detail') }}</textarea>
            @error('detail')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- SEO Section Divider -->
          <div class="col-12 pt-3">
            <div class="d-flex align-items-center justify-content-between border-bottom pb-2">
              <h6 class="fw-bold mb-0" style="color: #061E43;">
                <i class="bi bi-search me-1 text-primary"></i> SEO &amp; Social Share Metadata
              </h6>
              <span class="badge bg-light text-muted border small">
                <i class="bi bi-magic me-1 text-warning"></i> Auto-synced from Name, Detail &amp; Photo (Editable)
              </span>
            </div>
          </div>

          <!-- 6. Meta Title (Auto-synced from Name) -->
          <div class="col-12">
            <label class="form-label fw-bold small d-flex justify-content-between align-items-center" for="meta_title">
              <span>Meta Title</span>
              <small class="text-muted fw-normal">Auto-filled from Product Name (you can change it)</small>
            </label>
            <input type="text" class="form-control @error('meta_title') is-invalid @enderror" id="meta_title" name="meta_title" value="{{ old('meta_title') }}" placeholder="Auto-filled from Product Name...">
            @error('meta_title')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 7. Meta Detail (Auto-synced from Detail) -->
          <div class="col-12">
            <label class="form-label fw-bold small d-flex justify-content-between align-items-center" for="meta_detail">
              <span>Meta Detail / Description</span>
              <small class="text-muted fw-normal">Auto-filled from Product Detail (you can change it)</small>
            </label>
            <textarea class="form-control @error('meta_detail') is-invalid @enderror" id="meta_detail" name="meta_detail" rows="2" placeholder="Auto-filled from Product Detail...">{{ old('meta_detail') }}</textarea>
            @error('meta_detail')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- 8. OG Image (File Upload - Defaults to Product Photo if empty) -->
          <div class="col-12">
            <label class="form-label fw-bold small d-flex justify-content-between align-items-center" for="og_image">
              <span>OG Image (Social Share Image)</span>
              <small class="text-muted fw-normal">Optional: Product photo is automatically used if left empty</small>
            </label>
            <input type="file" class="form-control @error('og_image') is-invalid @enderror" id="og_image" name="og_image" accept="image/*">
            <div class="form-text small">Leave empty to automatically use the main Product Photo, or upload a custom image.</div>
            @error('og_image')
              <div class="invalid-feedback">{{ $message }}</div>
            @enderror
          </div>

          <!-- Submit Buttons -->
          <div class="col-12 pt-3">
            <hr>
            <div class="d-flex justify-content-end gap-2">
              <a href="{{ route('admin.products.index') }}" class="btn btn-outline-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary px-4">
                <i class="bi bi-check-circle me-1"></i> Save Product
              </button>
            </div>
          </div>

        </div>
      </form>
    </div>
  </div>

</div>

<!-- Simple Auto-Sync JavaScript (Beginner Friendly) -->
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const nameInput = document.getElementById('name');
    const metaTitleInput = document.getElementById('meta_title');
    const detailInput = document.getElementById('detail');
    const metaDetailInput = document.getElementById('meta_detail');

    let metaTitleManuallyChanged = metaTitleInput.value.trim().length > 0;
    let metaDetailManuallyChanged = metaDetailInput.value.trim().length > 0;

    // Track if user explicitly edits Meta Title
    metaTitleInput.addEventListener('input', function() {
      metaTitleManuallyChanged = true;
    });

    // Track if user explicitly edits Meta Detail
    metaDetailInput.addEventListener('input', function() {
      metaDetailManuallyChanged = true;
    });

    // 1. Auto-copy Name to Meta Title as user types
    nameInput.addEventListener('input', function() {
      if (!metaTitleManuallyChanged) {
        metaTitleInput.value = nameInput.value;
      }
    });

    // 2. Auto-copy Detail to Meta Detail as user types
    detailInput.addEventListener('input', function() {
      if (!metaDetailManuallyChanged) {
        metaDetailInput.value = detailInput.value;
      }
    });
  });
</script>
@endsection
