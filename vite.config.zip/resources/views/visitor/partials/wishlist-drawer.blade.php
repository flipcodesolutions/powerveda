<!-- Offcanvas Wishlist Drawer -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="wishlistOffcanvas" aria-labelledby="wishlistOffcanvasLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="wishlistOffcanvasLabel">
      <i class="bi bi-heart-fill me-2 text-danger"></i> Saved Wishlist
    </h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body p-3" id="wishlist-items-list">
    <!-- Dynamically Rendered by script.js -->
  </div>
</div>
