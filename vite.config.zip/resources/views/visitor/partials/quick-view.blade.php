<!-- Product Quick View Modal -->
<div class="modal fade" id="quickViewModal" tabindex="-1" aria-labelledby="quickViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content rounded-3 border-0 shadow-lg overflow-hidden">
      <div class="modal-header border-0 pb-0">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4 pt-0">
        <div class="row align-items-center g-4">
          <div class="col-md-6 text-center">
            <img id="qv-img" src="" alt="Product" class="img-fluid rounded-3 shadow-sm"
              style="max-height: 320px; width: 100%; object-fit: cover;">
          </div>
          <div class="col-md-6">
            <span class="badge-natural" id="qv-badge"
              style="position: static; display: inline-block; margin-bottom: 0.5rem;">[ NATURAL ]</span>
            <h3 class="mt-1 mb-2" id="qv-title" style="color: var(--heading-color);">Product Title</h3>

            <div class="d-flex align-items-baseline gap-2 mb-3">
              <span class="fs-3 fw-bold" id="qv-price" style="color: var(--heading-color);">₹0</span>
              <span class="text-muted text-decoration-line-through" id="qv-original-price">₹0</span>
              <span class="price-badge-gold" id="qv-discount">25% OFF</span>
            </div>

            <p class="text-muted small mb-4" id="qv-desc">Product description will appear here.</p>

            <div class="d-flex align-items-center gap-3 mb-4">
              <span class="fw-bold small" style="color: var(--heading-color);">Quantity:</span>
              <div class="cart-qty-control">
                <button class="cart-qty-btn" onclick="adjustQuickViewQty(-1)">-</button>
                <span class="cart-qty-val" id="qv-qty-val">1</span>
                <button class="cart-qty-btn" onclick="adjustQuickViewQty(1)">+</button>
              </div>
            </div>

            <button class="btn btn-primary w-100" onclick="addQuickViewToCart()">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
