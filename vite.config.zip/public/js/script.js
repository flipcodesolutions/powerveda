/**
 * Power Veda - Premium Wellness & Strength
 * JavaScript Interactive Functionality (Static Product DOM Integration)
 */

// --------------------------------------------------------------------------
// 1. Products Database Definition (Used for Cart, Wishlist & Quick View)
// --------------------------------------------------------------------------
const productsData = [
  {
    id: 1,
    name: "Power Veda Ashwagandha Gold KSM-66",
    price: 1499,
    originalPrice: 1999,
    discount: "25% OFF",
    rating: 5.0,
    reviews: 240,
    badge: "NATURAL",
    image: "image/products/product-1.jpg",
    description: "Premium full-spectrum organic root extract designed to boost physical vitality, reduce stress, and enhance muscle endurance."
  },
  {
    id: 2,
    name: "Power Veda Himalayan Detox Elixir",
    price: 899,
    originalPrice: 1199,
    discount: "25% OFF",
    rating: 4.8,
    reviews: 135,
    badge: "100% PURE",
    image: "image/products/product-2.jpg",
    description: "Handcrafted botanical blend of holy tulsi, lemongrass, and antioxidant herbs for cellular rejuvenation and daily detox."
  },
  {
    id: 3,
    name: "Power Veda 24K Saffron Radiance Elixir",
    price: 2499,
    originalPrice: 3299,
    discount: "24% OFF",
    rating: 5.0,
    reviews: 310,
    badge: "PREMIUM",
    image: "image/products/product-3.jpg",
    description: "Sacred facial and skin radiance elixir formulated with pure Kashmiri saffron, sandalwood, and lotus blossoms."
  },
  {
    id: 4,
    name: "Power Veda Triphala Gut Vitality",
    price: 799,
    originalPrice: 999,
    discount: "20% OFF",
    rating: 4.7,
    reviews: 95,
    badge: "VITALITY",
    image: "image/products/product-4.jpg",
    description: "Time-tested three-fruit botanical formula supporting digestion, nutrient absorption, and body purification."
  },
  {
    id: 5,
    name: "Power Veda Brahmi Mind Focus Tonic",
    price: 1199,
    originalPrice: 1599,
    discount: "25% OFF",
    rating: 4.9,
    reviews: 160,
    badge: "STRENGTH",
    image: "image/products/product-5.jpg",
    description: "Cognitive enhancement formulation supporting peak memory clarity, sharp focus, and nervous system health."
  },
  {
    id: 6,
    name: "Power Veda Turmeric Curcumin 95%",
    price: 1299,
    originalPrice: 1699,
    discount: "23% OFF",
    rating: 4.9,
    reviews: 215,
    badge: "IMMUNITY",
    image: "image/products/product-6.jpg",
    description: "Ultra-potent golden turmeric extract formulated with BioPerine for joint flexibility, vitality, and robust immunity."
  },
  {
    id: 7,
    name: "Power Veda Neem & Tulsi Purifying Cleanse",
    price: 699,
    originalPrice: 899,
    discount: "22% OFF",
    rating: 4.8,
    reviews: 112,
    badge: "WELLNESS",
    image: "image/products/product-7.jpg",
    description: "Gentle soap-free foaming wash that balances natural skin oils and deeply purifies pores with sacred botanicals."
  },
  {
    id: 8,
    name: "Power Veda Cold-Pressed Sweet Almond Oil",
    price: 999,
    originalPrice: 1299,
    discount: "23% OFF",
    rating: 4.9,
    reviews: 180,
    badge: "COLD PRESSED",
    image: "image/products/product-8.jpg",
    description: "100% unrefined therapeutic oil rich in natural Vitamin E, perfect for restorative body massage and muscle recovery."
  }
];

// --------------------------------------------------------------------------
// 2. State (Cart & Wishlist)
// --------------------------------------------------------------------------
let cart = JSON.parse(localStorage.getItem('powerveda_cart')) || [];
let wishlist = JSON.parse(localStorage.getItem('powerveda_wishlist')) || [];

function saveCart() {
  localStorage.setItem('powerveda_cart', JSON.stringify(cart));
  updateCartCounters();
  renderCartDrawer();
}

function saveWishlist() {
  localStorage.setItem('powerveda_wishlist', JSON.stringify(wishlist));
  updateWishlistCounters();
  renderWishlistDrawer();
  syncWishlistButtons();
}

// Sync heart icons on static HTML product cards
function syncWishlistButtons() {
  productsData.forEach(product => {
    const btn = document.getElementById(`wishlist-btn-${product.id}`);
    if (btn) {
      const isWishlisted = wishlist.includes(product.id);
      btn.classList.toggle('active', isWishlisted);
      btn.innerHTML = `<i class="bi ${isWishlisted ? 'bi-heart-fill text-danger' : 'bi-heart'}"></i>`;
      btn.title = isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist';
    }
  });
}

// --------------------------------------------------------------------------
// 3. Cart Operations
// --------------------------------------------------------------------------
function addToCart(productId, qty = 1) {
  const product = productsData.find(p => p.id === productId);
  if (!product) return;

  const existing = cart.find(item => item.id === productId);
  if (existing) {
    existing.qty += qty;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      qty: qty
    });
  }

  saveCart();
  showToast(`${product.name} added to cart!`, 'success');
}

function updateCartQty(productId, delta) {
  const item = cart.find(i => i.id === productId);
  if (!item) return;

  item.qty += delta;
  if (item.qty <= 0) {
    removeFromCart(productId);
    return;
  }
  saveCart();
}

function removeFromCart(productId) {
  const item = cart.find(i => i.id === productId);
  cart = cart.filter(i => i.id !== productId);
  saveCart();
  if (item) {
    showToast(`${item.name} removed from cart.`, 'info');
  }
}

function clearCart() {
  cart = [];
  saveCart();
  showToast('Cart cleared', 'info');
}

function updateCartCounters() {
  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
  document.querySelectorAll('.badge-cart-val').forEach(el => {
    el.innerText = totalItems;
  });
}

function renderCartDrawer() {
  const container = document.getElementById('cart-items-list');
  const footer = document.getElementById('cart-footer');
  if (!container) return;

  if (cart.length === 0) {
    container.innerHTML = `
      <div class="text-center py-5 px-3">
        <i class="bi bi-bag-x fs-1 text-muted mb-3 d-block"></i>
        <h5 class="fw-bold" style="color: var(--heading-color);">Your Cart is Empty</h5>
        <p class="text-muted small">Explore our pure wellness range to experience strength & vitality.</p>
        <button class="btn btn-primary btn-sm mt-2" data-bs-dismiss="offcanvas" onclick="location.href='#shop'">
          Shop Products
        </button>
      </div>
    `;
    if (footer) footer.style.display = 'none';
    return;
  }

  if (footer) footer.style.display = 'block';

  let subtotal = 0;
  container.innerHTML = cart.map(item => {
    const itemTotal = item.price * item.qty;
    subtotal += itemTotal;
    return `
      <div class="cart-item">
        <img src="${item.image}" alt="${item.name}" class="cart-item-img">
        <div class="cart-item-info">
          <div class="cart-item-title">${item.name}</div>
          <div class="cart-item-price">₹${item.price.toLocaleString('en-IN')}</div>
          <div class="cart-qty-control">
            <button class="cart-qty-btn" onclick="updateCartQty(${item.id}, -1)">-</button>
            <span class="cart-qty-val">${item.qty}</span>
            <button class="cart-qty-btn" onclick="updateCartQty(${item.id}, 1)">+</button>
          </div>
        </div>
        <button class="cart-item-remove" onclick="removeFromCart(${item.id})" title="Remove">
          <i class="bi bi-trash3"></i>
        </button>
      </div>
    `;
  }).join('');

  const shipping = subtotal >= 999 || subtotal === 0 ? 0 : 99;
  const total = subtotal + shipping;

  const subtotalEl = document.getElementById('cart-subtotal');
  const shippingEl = document.getElementById('cart-shipping');
  const totalEl = document.getElementById('cart-total');

  if (subtotalEl) subtotalEl.innerText = `₹${subtotal.toLocaleString('en-IN')}`;
  if (shippingEl) shippingEl.innerText = shipping === 0 ? 'FREE' : `₹${shipping}`;
  if (totalEl) totalEl.innerText = `₹${total.toLocaleString('en-IN')}`;
}

// --------------------------------------------------------------------------
// 4. Wishlist Operations
// --------------------------------------------------------------------------
function toggleWishlist(productId) {
  const product = productsData.find(p => p.id === productId);
  if (!product) return;

  const index = wishlist.indexOf(productId);
  if (index > -1) {
    wishlist.splice(index, 1);
    showToast(`${product.name} removed from wishlist`, 'info');
  } else {
    wishlist.push(productId);
    showToast(`${product.name} saved to wishlist!`, 'success');
  }

  saveWishlist();
}

function updateWishlistCounters() {
  const totalItems = wishlist.length;
  document.querySelectorAll('.badge-wishlist-val').forEach(el => {
    el.innerText = totalItems;
  });
}

function renderWishlistDrawer() {
  const container = document.getElementById('wishlist-items-list');
  if (!container) return;

  if (wishlist.length === 0) {
    container.innerHTML = `
      <div class="text-center py-5 px-3">
        <i class="bi bi-heart fs-1 text-muted mb-3 d-block"></i>
        <h5 class="fw-bold" style="color: var(--heading-color);">Your Wishlist is Empty</h5>
        <p class="text-muted small">Save your favorite wellness and vitality remedies here.</p>
      </div>
    `;
    return;
  }

  const items = productsData.filter(p => wishlist.includes(p.id));
  container.innerHTML = items.map(item => `
    <div class="cart-item">
      <img src="${item.image}" alt="${item.name}" class="cart-item-img">
      <div class="cart-item-info">
        <div class="cart-item-title">${item.name}</div>
        <div class="cart-item-price">₹${item.price.toLocaleString('en-IN')}</div>
        <button class="btn btn-sm btn-primary mt-2" onclick="addToCart(${item.id}); toggleWishlist(${item.id});">
          Move to Cart
        </button>
      </div>
      <button class="cart-item-remove" onclick="toggleWishlist(${item.id})" title="Remove">
        <i class="bi bi-trash3"></i>
      </button>
    </div>
  `).join('');
}

// --------------------------------------------------------------------------
// 5. Quick View Modal
// --------------------------------------------------------------------------
let quickViewQty = 1;
let currentQuickViewProduct = null;

function openQuickView(productId) {
  const product = productsData.find(p => p.id === productId);
  if (!product) return;

  currentQuickViewProduct = product;
  quickViewQty = 1;

  document.getElementById('qv-img').src = product.image;
  document.getElementById('qv-img').alt = product.name;
  document.getElementById('qv-title').innerText = product.name;
  document.getElementById('qv-badge').innerText = `[ ${product.badge} ]`;
  document.getElementById('qv-price').innerText = `₹${product.price.toLocaleString('en-IN')}`;
  document.getElementById('qv-original-price').innerText = `₹${product.originalPrice.toLocaleString('en-IN')}`;
  document.getElementById('qv-discount').innerText = product.discount;
  document.getElementById('qv-desc').innerText = product.description;
  document.getElementById('qv-qty-val').innerText = quickViewQty;

  const modalEl = document.getElementById('quickViewModal');
  const modal = new bootstrap.Modal(modalEl);
  modal.show();
}

function adjustQuickViewQty(delta) {
  quickViewQty = Math.max(1, quickViewQty + delta);
  document.getElementById('qv-qty-val').innerText = quickViewQty;
}

function addQuickViewToCart() {
  if (currentQuickViewProduct) {
    addToCart(currentQuickViewProduct.id, quickViewQty);
    const modalEl = document.getElementById('quickViewModal');
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
  }
}

// --------------------------------------------------------------------------
// 6. Search Filtering (Direct DOM Filter on Static HTML Cards)
// --------------------------------------------------------------------------
function setupSearch() {
  const searchInput = document.getElementById('product-search');
  const countEl = document.getElementById('formulation-count');
  if (!searchInput) return;

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase().trim();
    const productCols = document.querySelectorAll('.product-item-col');
    let visibleCount = 0;

    productCols.forEach(col => {
      const title = col.getAttribute('data-title') || '';
      const text = col.innerText || '';
      if (title.toLowerCase().includes(query) || text.toLowerCase().includes(query)) {
        col.style.display = 'block';
        visibleCount++;
      } else {
        col.style.display = 'none';
      }
    });

    if (countEl) {
      countEl.innerText = visibleCount;
    }
  });
}

// --------------------------------------------------------------------------
// 7. Flash Deal Countdown Timer
// --------------------------------------------------------------------------
function startCountdownTimer() {
  let targetTime = new Date().getTime() + (14 * 60 * 60 * 1000) + (30 * 60 * 1000);

  const hoursEl = document.getElementById('timer-hours');
  const minutesEl = document.getElementById('timer-minutes');
  const secondsEl = document.getElementById('timer-seconds');

  if (!hoursEl || !minutesEl || !secondsEl) return;

  function update() {
    const now = new Date().getTime();
    const distance = targetTime - now;

    if (distance <= 0) {
      targetTime = new Date().getTime() + (24 * 60 * 60 * 1000);
      return;
    }

    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);

    hoursEl.innerText = hours.toString().padStart(2, '0');
    minutesEl.innerText = minutes.toString().padStart(2, '0');
    secondsEl.innerText = seconds.toString().padStart(2, '0');
  }

  update();
  setInterval(update, 1000);
}

// --------------------------------------------------------------------------
// 8. Toast Notifications & Newsletter
// --------------------------------------------------------------------------
function showToast(message, type = 'success') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `custom-toast toast-${type}`;

  const icon = type === 'success' ? 'bi-check-circle-fill text-success' : 'bi-info-circle-fill text-primary';

  toast.innerHTML = `
    <div class="d-flex align-items-center gap-2">
      <i class="bi ${icon} fs-5"></i>
      <span style="font-size: 0.9rem; font-weight: 600;">${message}</span>
    </div>
    <button type="button" class="btn-close ms-2" style="font-size: 0.75rem;" aria-label="Close"></button>
  `;

  const closeBtn = toast.querySelector('.btn-close');
  closeBtn.addEventListener('click', () => toast.remove());

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

function setupNewsletter() {
  const form = document.getElementById('newsletter-form');
  if (!form) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const input = document.getElementById('newsletter-email');
    const email = input.value.trim();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      showToast('Please enter a valid email address.', 'info');
      input.focus();
      return;
    }

    showToast('Welcome to Power Veda Circle! Use code POWER35 for 35% off.', 'success');
    input.value = '';
  });
}

// --------------------------------------------------------------------------
// 9. Sticky Navbar, Auto-Close Mobile Menu, Back To Top
// --------------------------------------------------------------------------
function setupNavigation() {
  const header = document.querySelector('.site-header');
  const backToTopBtn = document.getElementById('back-to-top');

  window.addEventListener('scroll', () => {
    const scrollY = window.scrollY;

    if (header) {
      if (scrollY > 40) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    }

    if (backToTopBtn) {
      if (scrollY > 350) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }
  });

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Auto-close mobile navbar on link click or mobile action button click
  const mobileTriggers = document.querySelectorAll('.navbar-nav .nav-link, .mobile-menu-actions button');
  const navbarCollapse = document.querySelector('.navbar-collapse');
  mobileTriggers.forEach(el => {
    el.addEventListener('click', () => {
      if (navbarCollapse && navbarCollapse.classList.contains('show')) {
        const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
        if (bsCollapse) bsCollapse.hide();
      }
    });
  });
}

// --------------------------------------------------------------------------
// --------------------------------------------------------------------------
// 10. User Authentication & Account Management (Laravel MySQL Integration)
// --------------------------------------------------------------------------
let currentUser = JSON.parse(localStorage.getItem('powerveda_user')) || null;

function getCsrfToken() {
  const tokenMeta = document.querySelector('meta[name="csrf-token"]');
  return tokenMeta ? tokenMeta.getAttribute('content') : '';
}

function switchAuthTab(tabName) {
  const tabBtn = document.getElementById(tabName === 'register' ? 'register-tab' : 'login-tab');
  if (tabBtn) {
    const tab = new bootstrap.Tab(tabBtn);
    tab.show();
  }
}

async function checkAuthStatus() {
  try {
    const response = await fetch('/user/me', {
      headers: {
        'Accept': 'application/json',
        'X-CSRF-TOKEN': getCsrfToken()
      }
    });
    if (response.ok) {
      const data = await response.json();
      if (data.authenticated && data.user) {
        currentUser = data.user;
        localStorage.setItem('powerveda_user', JSON.stringify(currentUser));
      } else {
        currentUser = null;
        localStorage.removeItem('powerveda_user');
      }
      updateAccountUI();
    }
  } catch (err) {
    updateAccountUI();
  }
}

function updateAccountUI() {
  const desktopBtn = document.getElementById('desktop-account-btn');
  const desktopOrdersBtn = document.getElementById('desktop-orders-btn');
  const mobileLink = document.getElementById('mobile-auth-link');
  const mobileOrdersItem = document.getElementById('mobile-orders-item');

  if (currentUser) {
    const firstName = (currentUser.name || 'Member').split(' ')[0];

    // 1. Account Button
    if (desktopBtn) {
      desktopBtn.title = `Signed in as ${currentUser.name} (${currentUser.role || 'User'})`;
      desktopBtn.style.color = 'var(--gold-color)';
      desktopBtn.innerHTML = '<i class="bi bi-person-check-fill" style="color: var(--gold-color);"></i>';
    }

    // 2. Show My Orders only when logged in
    if (desktopOrdersBtn) {
      desktopOrdersBtn.classList.remove('d-none');
    }
    if (mobileOrdersItem) {
      mobileOrdersItem.classList.remove('d-none');
    }

    // 3. Mobile Drawer Account Status
    if (mobileLink) {
      mobileLink.innerHTML = `
        <span class="nav-left">
          <i class="bi bi-person-check-fill nav-icon text-warning"></i> Hi, ${firstName} (${currentUser.role || 'User'})
        </span>
        <span class="badge" style="background: rgba(216, 188, 141, 0.2); color: var(--gold-color); font-size: 0.7rem;">Active</span>
      `;
    }
  } else {
    // 1. Account Button
    if (desktopBtn) {
      desktopBtn.title = 'Account / Sign In';
      desktopBtn.style.color = '';
      desktopBtn.innerHTML = '<i class="bi bi-person"></i>';
    }

    // 2. Hide My Orders when not logged in
    if (desktopOrdersBtn) {
      desktopOrdersBtn.classList.add('d-none');
    }
    if (mobileOrdersItem) {
      mobileOrdersItem.classList.add('d-none');
    }

    // 3. Mobile Drawer Account Status
    if (mobileLink) {
      mobileLink.innerHTML = `
        <span class="nav-left">
          <i class="bi bi-person-circle nav-icon"></i> Sign In / Create Account
        </span>
        <i class="bi bi-chevron-right arrow-icon"></i>
      `;
    }
  }
}

async function handleLoginSubmit(event) {
  event.preventDefault();
  const alertEl = document.getElementById('login-alert');
  const spinnerEl = document.getElementById('login-spinner');
  const submitBtn = document.getElementById('login-submit-btn');
  const emailInput = document.getElementById('login-email');
  const passwordInput = document.getElementById('login-password');
  const rememberInput = document.getElementById('remember-me');

  if (alertEl) {
    alertEl.classList.add('d-none');
    alertEl.innerText = '';
  }
  if (spinnerEl) spinnerEl.classList.remove('d-none');
  if (submitBtn) submitBtn.disabled = true;

  try {
    const response = await fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-TOKEN': getCsrfToken()
      },
      body: JSON.stringify({
        login: emailInput ? emailInput.value.trim() : '',
        password: passwordInput ? passwordInput.value : '',
        remember: rememberInput ? rememberInput.checked : true
      })
    });

    const data = await response.json();

    if (response.ok && data.success) {
      currentUser = data.user;
      localStorage.setItem('powerveda_user', JSON.stringify(currentUser));
      updateAccountUI();

      const authModalEl = document.getElementById('authModal');
      const modal = bootstrap.Modal.getInstance(authModalEl);
      if (modal) modal.hide();

      showToast(data.message || `Welcome back, ${currentUser.name}!`, 'success');

      if (data.user && data.user.is_admin) {
        setTimeout(() => {
          showToast('Admin Access detected. You can manage the store from Admin Console.', 'info');
        }, 1500);
      }
    } else {
      const errMsg = (data.errors && Object.values(data.errors).flat()[0]) || data.message || 'Login failed. Please check your credentials.';
      if (alertEl) {
        alertEl.innerText = errMsg;
        alertEl.classList.remove('d-none');
      } else {
        showToast(errMsg, 'error');
      }
    }
  } catch (err) {
    if (alertEl) {
      alertEl.innerText = 'Unable to connect to server. Please try again.';
      alertEl.classList.remove('d-none');
    }
  } finally {
    if (spinnerEl) spinnerEl.classList.add('d-none');
    if (submitBtn) submitBtn.disabled = false;
  }
}

async function handleRegisterSubmit(event) {
  event.preventDefault();
  const alertEl = document.getElementById('register-alert');
  const spinnerEl = document.getElementById('register-spinner');
  const submitBtn = document.getElementById('register-submit-btn');
  const nameInput = document.getElementById('reg-name');
  const emailInput = document.getElementById('reg-email');
  const phoneInput = document.getElementById('reg-phone');
  const passwordInput = document.getElementById('reg-password');

  if (alertEl) {
    alertEl.classList.add('d-none');
    alertEl.innerText = '';
  }
  if (spinnerEl) spinnerEl.classList.remove('d-none');
  if (submitBtn) submitBtn.disabled = true;

  try {
    const response = await fetch('/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-TOKEN': getCsrfToken()
      },
      body: JSON.stringify({
        name: nameInput ? nameInput.value.trim() : '',
        email: emailInput ? emailInput.value.trim() : '',
        contactNo: phoneInput ? phoneInput.value.trim() : '',
        password: passwordInput ? passwordInput.value : ''
      })
    });

    const data = await response.json();

    if (response.ok && data.success) {
      currentUser = data.user;
      localStorage.setItem('powerveda_user', JSON.stringify(currentUser));
      updateAccountUI();

      const authModalEl = document.getElementById('authModal');
      const modal = bootstrap.Modal.getInstance(authModalEl);
      if (modal) modal.hide();

      showToast(data.message || `Welcome to Power Veda, ${currentUser.name}!`, 'success');
    } else {
      const errMsg = (data.errors && Object.values(data.errors).flat()[0]) || data.message || 'Registration failed. Please check your inputs.';
      if (alertEl) {
        alertEl.innerText = errMsg;
        alertEl.classList.remove('d-none');
      } else {
        showToast(errMsg, 'error');
      }
    }
  } catch (err) {
    if (alertEl) {
      alertEl.innerText = 'Unable to connect to server. Please try again.';
      alertEl.classList.remove('d-none');
    }
  } finally {
    if (spinnerEl) spinnerEl.classList.add('d-none');
    if (submitBtn) submitBtn.disabled = false;
  }
}

async function handleLogout() {
  try {
    await fetch('/logout', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'X-CSRF-TOKEN': getCsrfToken()
      }
    });
  } catch (err) {
    console.debug('Logout request error:', err);
  } finally {
    currentUser = null;
    localStorage.removeItem('powerveda_user');
    updateAccountUI();
    showToast('You have been signed out successfully.', 'info');
    setTimeout(() => { window.location.reload(); }, 500);
  }
}

function togglePasswordVisibility(inputId, btn) {
  const input = document.getElementById(inputId);
  if (!input) return;

  if (input.type === 'password') {
    input.type = 'text';
    btn.innerHTML = '<i class="bi bi-eye-slash"></i>';
  } else {
    input.type = 'password';
    btn.innerHTML = '<i class="bi bi-eye"></i>';
  }
}

// --------------------------------------------------------------------------
// 11. My Orders & Reorder Logic
// --------------------------------------------------------------------------
function reorderItems(productIds) {
  productIds.forEach(id => addToCart(id, 1));

  // Close orders modal
  const ordersModalEl = document.getElementById('myOrdersModal');
  const ordersModal = bootstrap.Modal.getInstance(ordersModalEl);
  if (ordersModal) ordersModal.hide();

  // Open Cart Drawer
  const cartDrawerEl = document.getElementById('cartOffcanvas');
  if (cartDrawerEl) {
    const bsCart = new bootstrap.Offcanvas(cartDrawerEl);
    bsCart.show();
  }

  showToast('Items added to your bag from past order!', 'success');
}

function trackOrderModal(orderId, statusMsg) {
  showToast(`Tracking #${orderId}: ${statusMsg}`, 'info');
}

// --------------------------------------------------------------------------
// 12. Testimonials Slider Functionality
// --------------------------------------------------------------------------
function setupTestimonialsSlider() {
  const track = document.getElementById('testimonials-slider-track');
  const container = document.getElementById('testimonials-track-container');
  const prevBtn = document.getElementById('testimonial-prev');
  const nextBtn = document.getElementById('testimonial-next');
  const dotsContainer = document.getElementById('testimonials-dots');

  if (!track || !container) return;

  const slides = track.querySelectorAll('.testimonial-slide-item');
  if (slides.length === 0) return;

  let currentIndex = 0;
  let autoplayTimer = null;
  let touchStartX = 0;
  let touchEndX = 0;

  function getVisibleCount() {
    if (window.innerWidth < 768) return 1;
    if (window.innerWidth < 992) return 2;
    return 3;
  }

  function getMaxIndex() {
    const visibleCount = getVisibleCount();
    return Math.max(0, slides.length - visibleCount);
  }

  function renderDots() {
    if (!dotsContainer) return;
    dotsContainer.innerHTML = '';
    const maxIdx = getMaxIndex();
    if (maxIdx <= 0) {
      if (prevBtn) prevBtn.style.display = 'none';
      if (nextBtn) nextBtn.style.display = 'none';
      return;
    }

    if (prevBtn) prevBtn.style.display = 'flex';
    if (nextBtn) nextBtn.style.display = 'flex';

    for (let i = 0; i <= maxIdx; i++) {
      const dot = document.createElement('button');
      dot.type = 'button';
      dot.className = `testimonial-dot ${i === currentIndex ? 'active' : ''}`;
      dot.setAttribute('aria-label', `Go to testimonial slide ${i + 1}`);
      dot.addEventListener('click', () => {
        goToSlide(i);
        resetAutoplay();
      });
      dotsContainer.appendChild(dot);
    }
  }

  function updateDots() {
    if (!dotsContainer) return;
    const dots = dotsContainer.querySelectorAll('.testimonial-dot');
    dots.forEach((dot, idx) => {
      dot.classList.toggle('active', idx === currentIndex);
    });
  }

  function goToSlide(index) {
    const maxIdx = getMaxIndex();
    currentIndex = Math.max(0, Math.min(index, maxIdx));

    const visibleCount = getVisibleCount();
    const gap = 24; // 1.5rem
    const slideWidth = (container.clientWidth - (gap * (visibleCount - 1))) / visibleCount;
    const shift = currentIndex * (slideWidth + gap);

    track.style.transform = `translateX(-${shift}px)`;
    updateDots();

    if (prevBtn) prevBtn.style.opacity = currentIndex === 0 ? '0.5' : '1';
    if (nextBtn) nextBtn.style.opacity = currentIndex === maxIdx ? '0.5' : '1';
  }

  function nextSlide() {
    const maxIdx = getMaxIndex();
    if (currentIndex >= maxIdx) {
      goToSlide(0);
    } else {
      goToSlide(currentIndex + 1);
    }
  }

  function prevSlide() {
    const maxIdx = getMaxIndex();
    if (currentIndex <= 0) {
      goToSlide(maxIdx);
    } else {
      goToSlide(currentIndex - 1);
    }
  }

  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      prevSlide();
      resetAutoplay();
    });
  }

  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      nextSlide();
      resetAutoplay();
    });
  }

  function startAutoplay() {
    stopAutoplay();
    autoplayTimer = setInterval(() => {
      nextSlide();
    }, 5000);
  }

  function stopAutoplay() {
    if (autoplayTimer) {
      clearInterval(autoplayTimer);
      autoplayTimer = null;
    }
  }

  function resetAutoplay() {
    stopAutoplay();
    startAutoplay();
  }

  container.addEventListener('mouseenter', stopAutoplay);
  container.addEventListener('mouseleave', startAutoplay);

  // Touch Swipe Support
  container.addEventListener('touchstart', (e) => {
    touchStartX = e.changedTouches[0].screenX;
    stopAutoplay();
  }, { passive: true });

  container.addEventListener('touchend', (e) => {
    touchEndX = e.changedTouches[0].screenX;
    if (touchStartX - touchEndX > 50) {
      nextSlide();
    } else if (touchEndX - touchStartX > 50) {
      prevSlide();
    }
    startAutoplay();
  }, { passive: true });

  window.addEventListener('resize', () => {
    renderDots();
    goToSlide(currentIndex);
  });

  renderDots();
  goToSlide(0);
  startAutoplay();
}

// --------------------------------------------------------------------------
// 14. Contact Form Submission (AJAX with Backend Storage)
// --------------------------------------------------------------------------
async function handleContactSubmit(event) {
  event.preventDefault();
  const alertEl = document.getElementById('contact-alert');
  const successAlertEl = document.getElementById('contact-success-alert');
  const spinnerEl = document.getElementById('contact-spinner');
  const submitBtn = document.getElementById('contact-submit-btn');

  const nameInput = document.getElementById('contact-name');
  const emailInput = document.getElementById('contact-email');
  const phoneInput = document.getElementById('contact-phone');
  const subjectInput = document.getElementById('contact-subject');
  const messageInput = document.getElementById('contact-message');

  if (alertEl) {
    alertEl.classList.add('d-none');
    alertEl.innerText = '';
  }
  if (successAlertEl) {
    successAlertEl.classList.add('d-none');
    successAlertEl.innerText = '';
  }
  if (spinnerEl) spinnerEl.classList.remove('d-none');
  if (submitBtn) submitBtn.disabled = true;

  try {
    const response = await fetch('/contact', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-CSRF-TOKEN': getCsrfToken()
      },
      body: JSON.stringify({
        name: nameInput ? nameInput.value.trim() : '',
        email: emailInput ? emailInput.value.trim() : '',
        contactno: phoneInput ? phoneInput.value.trim() : '',
        subject: subjectInput ? subjectInput.value.trim() : '',
        messages: messageInput ? messageInput.value.trim() : ''
      })
    });

    const data = await response.json();

    if (response.ok && data.success) {
      if (successAlertEl) {
        successAlertEl.innerHTML = `<i class="bi bi-check-circle-fill text-success me-2"></i> ${data.message}`;
        successAlertEl.classList.remove('d-none');
      }

      showToast(data.message || 'Thank you! Your message has been sent.', 'success');

      // Reset Form
      const form = document.getElementById('contact-form');
      if (form) form.reset();
    } else {
      const errMsg = (data.errors && Object.values(data.errors).flat()[0]) || data.message || 'Please check all required fields and try again.';
      if (alertEl) {
        alertEl.innerText = errMsg;
        alertEl.classList.remove('d-none');
      } else {
        showToast(errMsg, 'error');
      }
    }
  } catch (err) {
    if (alertEl) {
      alertEl.innerText = 'Unable to send message at this time. Please try again or reach us via email.';
      alertEl.classList.remove('d-none');
    }
  } finally {
    if (spinnerEl) spinnerEl.classList.add('d-none');
    if (submitBtn) submitBtn.disabled = false;
  }
}

// --------------------------------------------------------------------------
// 15. Initialization
// --------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', () => {
  syncWishlistButtons();
  setupSearch();
  updateCartCounters();
  renderCartDrawer();
  updateWishlistCounters();
  renderWishlistDrawer();
  startCountdownTimer();
  setupNavigation();
  checkAuthStatus();
  setupTestimonialsSlider();
});
