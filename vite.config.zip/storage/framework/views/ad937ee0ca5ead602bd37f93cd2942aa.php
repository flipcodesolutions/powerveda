<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Power Veda Admin Console. Manage botanical formulations, customer orders, and verified customer reviews.">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('page_title', 'Admin Dashboard'); ?> | Power Veda HQ</title>

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="<?php echo e(asset('image/logo.png')); ?>">

  <!-- Google Fonts: Syne (Headings) & Plus Jakarta Sans (Body) -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">

  <!-- Bootstrap 5.3 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <!-- Brand CSS & Admin Specific CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
  <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="admin-body">

  <!-- 1. Admin Sidebar Navigation -->
  <?php echo $__env->make('admin.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- 2. Admin Main Content Wrapper -->
  <main class="admin-main">

    <!-- Topbar -->
    <?php echo $__env->make('admin.partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Admin Body Content -->
    <div class="admin-content">
      <?php echo $__env->yieldContent('content'); ?>
    </div>

  </main>

  <!-- Common Modals -->
  <?php echo $__env->make('admin.partials.order-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Toast Notification Container -->
  <div class="toast-container-custom" id="toast-container" aria-live="polite" aria-atomic="true"></div>

  <!-- Bootstrap Bundle JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Admin Script -->
  <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>