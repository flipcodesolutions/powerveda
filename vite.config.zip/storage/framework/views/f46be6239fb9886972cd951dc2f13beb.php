<!-- Offcanvas Shopping Cart Drawer -->
<div class="offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas" aria-labelledby="cartOffcanvasLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="cartOffcanvasLabel">
      <i class="bi bi-bag-check-fill me-2"></i> Your Cart
    </h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body d-flex flex-column p-0">
    <div class="px-3 flex-grow-1 overflow-auto" id="cart-items-list">
      <!-- Dynamically Rendered by script.js -->
    </div>
    <div class="cart-footer-summary" id="cart-footer">
      <div class="cart-summary-row">
        <span>Subtotal:</span>
        <span class="fw-bold" id="cart-subtotal">₹0</span>
      </div>
      <div class="cart-summary-row">
        <span>Shipping:</span>
        <span class="fw-bold text-success" id="cart-shipping">FREE</span>
      </div>
      <div class="cart-summary-row total">
        <span>Total:</span>
        <span id="cart-total">₹0</span>
      </div>
      <button class="btn btn-primary w-100 mt-3" onclick="showToast('Proceeding to Secure Checkout...', 'success')">
        <i class="bi bi-lock-fill"></i> SECURE CHECKOUT
      </button>
      <button class="btn btn-sm btn-link text-muted w-100 mt-2" onclick="clearCart()">
        Clear Cart
      </button>
    </div>
  </div>
</div>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/partials/cart-drawer.blade.php ENDPATH**/ ?>