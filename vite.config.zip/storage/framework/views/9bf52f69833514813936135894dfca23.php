<!-- Luxury Mobile Navigation Drawer (Offcanvas) -->
<div class="offcanvas offcanvas-start mobile-nav-offcanvas" tabindex="-1" id="mobileNavDrawer"
  aria-labelledby="mobileNavDrawerLabel">

  <!-- Drawer Header -->
  <div class="mobile-nav-header">
    <div class="d-flex align-items-center">
      <img src="<?php echo e(asset('image/logo.png')); ?>" alt="Power Veda Logo" width="160" height="38">
    </div>
    <button type="button" class="mobile-nav-close-btn" data-bs-dismiss="offcanvas" aria-label="Close">
      <i class="bi bi-x-lg"></i>
    </button>
  </div>

  <!-- Drawer Body -->
  <div class="offcanvas-body d-flex flex-column p-0">

    <!-- Quick Action Cards (Wishlist & Cart) -->
    <div class="mobile-quick-actions">
      <a href="javascript:void(0)" class="mobile-action-card" data-bs-dismiss="offcanvas" data-bs-toggle="offcanvas"
        data-bs-target="#wishlistOffcanvas">
        <i class="bi bi-heart-fill text-danger"></i>
        <span class="action-label">Wishlist</span>
        <span class="action-count"><span class="badge-wishlist-val">0</span> items</span>
      </a>
      <a href="javascript:void(0)" class="mobile-action-card" data-bs-dismiss="offcanvas" data-bs-toggle="offcanvas"
        data-bs-target="#cartOffcanvas">
        <i class="bi bi-bag-check-fill text-warning"></i>
        <span class="action-label">Cart</span>
        <span class="action-count"><span class="badge-cart-val">0</span> items</span>
      </a>
    </div>

    <!-- Navigation Menu Links -->
    <ul class="mobile-nav-list">
      <li class="mobile-nav-item">
        <a class="mobile-nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>#home" data-bs-dismiss="offcanvas">
          <span class="nav-left">
            <i class="bi bi-house-door nav-icon"></i> Home
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="<?php echo e(route('home')); ?>#shop" data-bs-dismiss="offcanvas">
          <span class="nav-left">
            <i class="bi bi-bag nav-icon"></i> Shop Formulations
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="<?php echo e(route('home')); ?>#why-us" data-bs-dismiss="offcanvas">
          <span class="nav-left">
            <i class="bi bi-shield-check nav-icon"></i> Why Power Veda
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="<?php echo e(route('home')); ?>#about" data-bs-dismiss="offcanvas">
          <span class="nav-left">
            <i class="bi bi-flower1 nav-icon"></i> Our Philosophy
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="<?php echo e(route('home')); ?>#reviews" data-bs-dismiss="offcanvas">
          <span class="nav-left">
            <i class="bi bi-star nav-icon"></i> Customer Reviews
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="javascript:void(0)" data-bs-dismiss="offcanvas" data-bs-toggle="modal"
          data-bs-target="#myOrdersModal">
          <span class="nav-left">
            <i class="bi bi-box-seam nav-icon"></i> My Orders &amp; Tracking
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="javascript:void(0)" data-bs-dismiss="offcanvas" data-bs-toggle="modal"
          data-bs-target="#authModal" id="mobile-auth-link">
          <span class="nav-left">
            <i class="bi bi-person-circle nav-icon"></i> Sign In / Create Account
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
      <li class="mobile-nav-item">
        <a class="mobile-nav-link" href="<?php echo e(route('home')); ?>#contact" data-bs-dismiss="offcanvas">
          <span class="nav-left">
            <i class="bi bi-telephone nav-icon"></i> Contact &amp; Support
          </span>
          <i class="bi bi-chevron-right arrow-icon"></i>
        </a>
      </li>
    </ul>

    <!-- Promo Badge Inside Mobile Menu -->
    <div class="mobile-nav-promo">
      <h6>⚡ 25% OFF SEASON SPECIAL</h6>
      <p>Use code <strong>POWER35</strong> on your order</p>
    </div>

    <!-- Drawer Footer -->
    <div class="mobile-nav-footer">
      <a href="tel:+918005558332" class="mobile-contact-btn">
        <i class="bi bi-telephone-fill"></i> +91 (800) 555-VEDA
      </a>
      <div class="mobile-social-row">
        <a href="https://facebook.com" class="social-icon-btn" target="_blank" rel="noopener noreferrer"
          aria-label="Facebook"><i class="bi bi-facebook"></i></a>
        <a href="https://instagram.com" class="social-icon-btn" target="_blank" rel="noopener noreferrer"
          aria-label="Instagram"><i class="bi bi-instagram"></i></a>
        <a href="https://youtube.com" class="social-icon-btn" target="_blank" rel="noopener noreferrer"
          aria-label="YouTube"><i class="bi bi-youtube"></i></a>
      </div>
    </div>

  </div>
</div>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/partials/mobile-drawer.blade.php ENDPATH**/ ?>