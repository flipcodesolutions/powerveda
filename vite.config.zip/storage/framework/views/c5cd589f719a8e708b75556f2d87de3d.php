<?php $__env->startSection('page_title', 'Add Customer Review'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">

  <!-- Validation Errors -->
  <?php if($errors->any()): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
      <h6 class="fw-bold mb-1"><i class="bi bi-exclamation-triangle-fill me-2"></i>Please fix the following errors:</h6>
      <ul class="mb-0 ps-3">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center border-bottom">
      <h5 class="mb-0 fw-bold" style="color: #061E43;">
        <i class="bi bi-plus-circle me-2 text-primary"></i>Add Customer Review / Testimonial
      </h5>
      <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-left"></i> Back to Reviews
      </a>
    </div>

    <div class="card-body p-4">
      <!-- Standard HTML Form -->
      <form action="<?php echo e(route('admin.reviews.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        <div class="row g-3">

          <!-- 1. Reviewer Name -->
          <div class="col-md-6">
            <label class="form-label fw-bold small" for="author">Reviewer / Customer Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="author" name="author" value="<?php echo e(old('author')); ?>" placeholder="e.g. Dr. Priya Nair" required>
            <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- 2. Location -->
          <div class="col-md-6">
            <label class="form-label fw-bold small" for="location">Location / City</label>
            <input type="text" class="form-control <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="location" name="location" value="<?php echo e(old('location')); ?>" placeholder="e.g. Mumbai, Maharashtra">
            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- 3. Formulation / Product Selection (Dynamic) -->
          <div class="col-12">
            <label class="form-label fw-bold small d-flex justify-content-between align-items-center" for="product_id">
              <span>Associated Product (Optional)</span>
              <span class="badge bg-light text-primary border small fw-normal">
                <i class="bi bi-lightning-charge-fill text-warning me-1"></i> Live Product Preview
              </span>
            </label>
            <select class="form-select <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="product_id" name="product_id">
              <option value="" data-name="General Store Review" data-price="" data-photo="" data-detail="Review applies to overall brand, packaging, delivery or general wellness experience." data-badge="STOREWIDE">
                -- General Store Review (No Specific Product) --
              </option>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($product->id); ?>"
                  data-name="<?php echo e($product->name); ?>"
                  data-price="₹<?php echo e(number_format($product->price, 0)); ?>"
                  data-photo="<?php echo e($product->photo_url); ?>"
                  data-detail="<?php echo e($product->detail); ?>"
                  data-badge="<?php echo e($product->badge ?: 'NATURAL'); ?>"
                  data-stock="<?php echo e($product->stock); ?>"
                  data-rating="<?php echo e($product->rating); ?>"
                  <?php echo e(old('product_id') == $product->id ? 'selected' : ''); ?>>
                  <?php echo e($product->name); ?> (₹<?php echo e(number_format($product->price, 0)); ?>)
                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <!-- Dynamic Live Product Card Preview -->
            <div id="product-preview-card" class="mt-3 p-3 rounded border bg-light d-flex align-items-center gap-3 transition-all" style="display: none;">
              <img id="preview-prod-img" src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="Product" class="rounded border bg-white" style="width: 65px; height: 65px; object-fit: cover;">
              <div class="flex-grow-1">
                <div class="d-flex align-items-center gap-2 flex-wrap mb-1">
                  <strong id="preview-prod-name" class="text-dark">Product Name</strong>
                  <span id="preview-prod-badge" class="badge bg-primary-subtle text-primary border small">NATURAL</span>
                  <span id="preview-prod-price" class="fw-bold text-success small">₹0</span>
                </div>
                <p id="preview-prod-detail" class="text-muted small mb-0" style="max-height: 40px; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">
                  Product description...
                </p>
              </div>
            </div>
          </div>

          <!-- 4. Star Rating -->
          <div class="col-md-6">
            <label class="form-label fw-bold small d-flex justify-content-between align-items-center" for="rating">
              <span>Star Rating <span class="text-danger">*</span></span>
              <span id="live-rating-stars" class="text-warning small">⭐⭐⭐⭐⭐ 5.0</span>
            </label>
            <select class="form-select <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="rating" name="rating" required>
              <option value="5" <?php echo e(old('rating', 5) == 5 ? 'selected' : ''); ?>>⭐⭐⭐⭐⭐ 5 Stars (Exceptional)</option>
              <option value="4" <?php echo e(old('rating') == 4 ? 'selected' : ''); ?>>⭐⭐⭐⭐ 4 Stars (Very Good)</option>
              <option value="3" <?php echo e(old('rating') == 3 ? 'selected' : ''); ?>>⭐⭐⭐ 3 Stars (Average)</option>
              <option value="2" <?php echo e(old('rating') == 2 ? 'selected' : ''); ?>>⭐⭐ 2 Stars (Below Average)</option>
              <option value="1" <?php echo e(old('rating') == 1 ? 'selected' : ''); ?>>⭐ 1 Star (Poor)</option>
            </select>
            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- 5. Moderation Status -->
          <div class="col-md-6">
            <label class="form-label fw-bold small" for="status">Status <span class="text-danger">*</span></label>
            <select class="form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="status" name="status" required>
              <option value="Approved" <?php echo e(old('status', 'Approved') === 'Approved' ? 'selected' : ''); ?>>Approved (Visible on Storefront)</option>
              <option value="Pending" <?php echo e(old('status') === 'Pending' ? 'selected' : ''); ?>>Pending Moderation</option>
              <option value="Hidden" <?php echo e(old('status') === 'Hidden' ? 'selected' : ''); ?>>Hidden</option>
            </select>
            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- 6. Reviewer Photo (File Upload + Live Preview) -->
          <div class="col-12">
            <label class="form-label fw-bold small" for="photo">Reviewer Photo / Avatar (File Upload)</label>
            <div class="d-flex align-items-center gap-3">
              <img id="avatar-preview-img" src="https://ui-avatars.com/api/?name=User&background=061E43&color=D8BC8D&size=100" alt="Avatar Preview" class="rounded-circle border" style="width: 50px; height: 50px; object-fit: cover;">
              <div class="flex-grow-1">
                <input type="file" class="form-control <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="photo" name="photo" accept="image/*">
                <div class="form-text small">Upload customer avatar image (JPG, PNG, WEBP - Max 2MB). Optional.</div>
              </div>
            </div>
            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback d-block"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- 7. Review / Feedback Comment -->
          <div class="col-12">
            <label class="form-label fw-bold small d-flex justify-content-between align-items-center" for="comment">
              <span>Review Feedback / Testimonial <span class="text-danger">*</span></span>
              <small id="comment-char-count" class="text-muted">0 characters</small>
            </label>
            <textarea class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="comment" name="comment" rows="4" placeholder="Enter customer's review feedback and experience with the botanical formulation..." required><?php echo e(old('comment')); ?></textarea>
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <!-- Submit Buttons -->
          <div class="col-12 pt-3">
            <hr>
            <div class="d-flex justify-content-end gap-2">
              <a href="<?php echo e(route('admin.reviews.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
              <button type="submit" class="btn btn-primary px-4">
                <i class="bi bi-check-circle me-1"></i> Save Review
              </button>
            </div>
          </div>

        </div>
      </form>
    </div>
  </div>

</div>

<!-- Dynamic UI JavaScript (Beginner Friendly, No AJAX) -->
<script>
  document.addEventListener('DOMContentLoaded', function() {
    const productSelect = document.getElementById('product_id');
    const previewCard = document.getElementById('product-preview-card');
    const previewImg = document.getElementById('preview-prod-img');
    const previewName = document.getElementById('preview-prod-name');
    const previewBadge = document.getElementById('preview-prod-badge');
    const previewPrice = document.getElementById('preview-prod-price');
    const previewDetail = document.getElementById('preview-prod-detail');

    const authorInput = document.getElementById('author');
    const avatarPreviewImg = document.getElementById('avatar-preview-img');
    const photoInput = document.getElementById('photo');

    const ratingSelect = document.getElementById('rating');
    const liveRatingStars = document.getElementById('live-rating-stars');

    const commentInput = document.getElementById('comment');
    const commentCharCount = document.getElementById('comment-char-count');

    // 1. Dynamic Product Selection Card Updater
    function updateProductPreview() {
      const selectedOption = productSelect.options[productSelect.selectedIndex];
      if (!selectedOption) return;

      const name = selectedOption.getAttribute('data-name') || '';
      const price = selectedOption.getAttribute('data-price') || '';
      const photo = selectedOption.getAttribute('data-photo') || '';
      const detail = selectedOption.getAttribute('data-detail') || '';
      const badge = selectedOption.getAttribute('data-badge') || 'NATURAL';

      if (productSelect.value) {
        previewCard.style.display = 'flex';
        previewName.innerText = name;
        previewPrice.innerText = price;
        previewBadge.innerText = badge;
        previewDetail.innerText = detail || 'No botanical details provided.';
        if (photo) {
          previewImg.src = photo;
          previewImg.style.display = 'block';
        } else {
          previewImg.style.display = 'none';
        }
      } else {
        previewCard.style.display = 'flex';
        previewName.innerText = 'General Store Review';
        previewPrice.innerText = '';
        previewBadge.innerText = 'STOREWIDE';
        previewDetail.innerText = 'Review applies to overall brand, packaging, delivery, or general customer wellness journey.';
        previewImg.src = '/image/logo.png';
      }
    }

    productSelect.addEventListener('change', updateProductPreview);
    updateProductPreview(); // Initialize on page load

    // 2. Dynamic Avatar Preview from Author Name & File Upload
    function updateAvatarFromName() {
      const name = authorInput.value.trim() || 'User';
      if (!photoInput.files || photoInput.files.length === 0) {
        avatarPreviewImg.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=061E43&color=D8BC8D&size=100`;
      }
    }

    authorInput.addEventListener('input', updateAvatarFromName);

    photoInput.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(evt) {
          avatarPreviewImg.src = evt.target.result;
        };
        reader.readAsDataURL(file);
      } else {
        updateAvatarFromName();
      }
    });

    // 3. Dynamic Rating Visualizer
    ratingSelect.addEventListener('change', function() {
      const starsCount = parseInt(ratingSelect.value, 10) || 5;
      liveRatingStars.innerText = '⭐'.repeat(starsCount) + ` ${starsCount}.0`;
    });

    // 4. Comment Character Counter
    commentInput.addEventListener('input', function() {
      const len = commentInput.value.length;
      commentCharCount.innerText = `${len} character${len === 1 ? '' : 's'}`;
    });
    if (commentInput.value) {
      commentCharCount.innerText = `${commentInput.value.length} characters`;
    }
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/pages/reviews/create.blade.php ENDPATH**/ ?>