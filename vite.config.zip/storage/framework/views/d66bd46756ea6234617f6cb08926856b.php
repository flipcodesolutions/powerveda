<?php $__env->startSection('page_title', 'Customer Reviews'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-0">

  <!-- Success Notification Message -->
  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2 mb-4" role="alert">
      <i class="bi bi-check-circle-fill fs-5"></i>
      <div><strong>Success!</strong> <?php echo e(session('success')); ?></div>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <!-- Reviews Card -->
  <div class="card border-0 shadow-sm rounded-3">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2 border-bottom">
      <div>
        <h5 class="mb-0 fw-bold" style="color: #061E43;">
          <i class="bi bi-star-fill me-2 text-warning"></i>All Customer Reviews
        </h5>
        <small class="text-muted">Manage testimonials, ratings, and customer feedback</small>
      </div>

      <!-- Add Button (Opens create.blade.php) -->
      <a href="<?php echo e(route('admin.reviews.create')); ?>" class="btn btn-primary d-flex align-items-center gap-2">
        <i class="bi bi-plus-circle"></i> Add Customer Review
      </a>
    </div>

    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-light">
            <tr>
              <th style="width: 60px;">Photo</th>
              <th>Reviewer</th>
              <th>Rating &amp; Feedback</th>
              <th>Product / Formulation</th>
              <th>Status</th>
              <th>Date</th>
              <th class="text-end" style="width: 140px;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <!-- 1. Photo / Avatar -->
                <td>
                  <img src="<?php echo e($review->photo_url); ?>" alt="<?php echo e($review->author); ?>" class="rounded-circle border" style="width: 42px; height: 42px; object-fit: cover;">
                </td>

                <!-- 2. Reviewer Name & Location -->
                <td>
                  <strong class="text-dark d-block"><?php echo e($review->author); ?></strong>
                  <small class="text-muted"><i class="bi bi-geo-alt me-1"></i><?php echo e($review->location ?: 'India'); ?></small>
                </td>

                <!-- 3. Rating & Feedback Comment -->
                <td>
                  <div class="mb-1 text-warning">
                    <?php for($i = 1; $i <= 5; $i++): ?>
                      <?php if($i <= $review->rating): ?>
                        <i class="bi bi-star-fill"></i>
                      <?php else: ?>
                        <i class="bi bi-star text-muted opacity-50"></i>
                      <?php endif; ?>
                    <?php endfor; ?>
                    <span class="text-dark fw-bold ms-1 small">(<?php echo e($review->rating); ?>.0)</span>
                  </div>
                  <div class="text-secondary small" style="max-width: 320px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" title="<?php echo e($review->comment); ?>">
                    "<?php echo e($review->comment); ?>"
                  </div>
                </td>

                <!-- 4. Associated Product -->
                <td>
                  <?php if($review->product): ?>
                    <span class="badge bg-light text-dark border">
                      <i class="bi bi-box-seam me-1 text-primary"></i><?php echo e($review->product->name); ?>

                    </span>
                  <?php else: ?>
                    <span class="badge bg-light text-secondary border">General Review</span>
                  <?php endif; ?>
                </td>

                <!-- 5. Status -->
                <td>
                  <?php if($review->status === 'Approved'): ?>
                    <span class="badge bg-success">Approved</span>
                  <?php elseif($review->status === 'Pending'): ?>
                    <span class="badge bg-warning text-dark">Pending</span>
                  <?php else: ?>
                    <span class="badge bg-secondary">Hidden</span>
                  <?php endif; ?>
                </td>

                <!-- 6. Date -->
                <td>
                  <small class="text-muted"><?php echo e($review->created_at ? $review->created_at->format('d M Y') : 'Recent'); ?></small>
                </td>

                <!-- 7. Actions (Standard Edit Link & Delete Form) -->
                <td class="text-end">
                  <div class="d-inline-flex gap-1">
                    <!-- Edit Link -->
                    <a href="<?php echo e(route('admin.reviews.edit', $review->id)); ?>" class="btn btn-sm btn-outline-primary" title="Edit Review">
                      <i class="bi bi-pencil-square"></i>
                    </a>

                    <!-- Delete Form (Standard POST with DELETE method) -->
                    <form action="<?php echo e(route('admin.reviews.destroy', $review->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete this review by \'<?php echo e(addslashes($review->author)); ?>\'?');" class="d-inline">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete Review">
                        <i class="bi bi-trash3"></i>
                      </button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="7" class="text-center py-5 text-muted">
                  <i class="bi bi-chat-square-quote fs-1 d-block mb-2 text-secondary"></i>
                  No reviews found. <a href="<?php echo e(route('admin.reviews.create')); ?>">Click here to add your first customer review</a>.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/pages/reviews/index.blade.php ENDPATH**/ ?>