<?php $__env->startSection('page_title', 'Manage Product Catalog'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-tab-content" id="tab-products">

  <?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2 mb-4" role="alert">
      <i class="bi bi-check-circle-fill fs-5"></i>
      <div><?php echo e(session('success')); ?></div>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <div class="admin-panel-card">
    <div class="admin-panel-header">
      <div class="d-flex align-items-center gap-3 flex-wrap">
        <h3 class="admin-panel-title">
          Product Catalog <span class="badge bg-primary rounded-pill small ms-1" id="product-count-badge"><?php echo e($products->count()); ?></span>
        </h3>
        <div class="admin-search-input">
          <i class="bi bi-search"></i>
          <input type="text" id="admin-product-search" placeholder="Search formulations, badges, SEO..." value="<?php echo e(request('search')); ?>">
        </div>
      </div>
      <button class="btn btn-primary d-flex align-items-center gap-2 shadow-sm" onclick="openAddProductModal()">
        <i class="bi bi-plus-lg"></i> Add New Product
      </button>
    </div>

    <div class="table-responsive">
      <table class="table admin-table align-middle">
        <thead>
          <tr>
            <th>Product &amp; Photo</th>
            <th>Price (₹)</th>
            <th>Stock Status</th>
            <th>Formulation Detail</th>
            <th>SEO &amp; OG Image</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody id="products-table-body">
          <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr id="product-row-<?php echo e($product->id); ?>">
              <td>
                <div class="d-flex align-items-center gap-3">
                  <div class="position-relative" style="width: 52px; height: 52px; flex-shrink: 0;">
                    <img src="<?php echo e($product->photo_url); ?>" alt="<?php echo e($product->name); ?>" class="table-product-img rounded-3 border shadow-xs" style="width: 100%; height: 100%; object-fit: cover;">
                  </div>
                  <div>
                    <strong class="d-block text-dark fw-bold" style="font-size: 0.92rem;"><?php echo e($product->name); ?></strong>
                    <div class="d-flex align-items-center gap-2 mt-1">
                      <span class="badge bg-light text-muted border small">[ <?php echo e($product->badge ?: 'NATURAL'); ?> ]</span>
                      <span class="text-muted small"><i class="bi bi-star-fill text-warning"></i> <?php echo e(number_format($product->rating, 1)); ?> (<?php echo e($product->reviews_count); ?>)</span>
                    </div>
                  </div>
                </div>
              </td>
              <td>
                <div class="fw-bold" style="color: #061E43; font-size: 0.95rem;">₹<?php echo e(number_format($product->price, 2)); ?></div>
                <?php if($product->original_price): ?>
                  <del class="text-muted small">₹<?php echo e(number_format($product->original_price, 2)); ?></del>
                <?php endif; ?>
                <?php if($product->discount): ?>
                  <span class="badge bg-warning text-dark small ms-1"><?php echo e($product->discount); ?></span>
                <?php endif; ?>
              </td>
              <td>
                <div class="fw-bold"><?php echo e($product->stock); ?> units</div>
                <span class="badge-status <?php echo e($product->stock <= 0 ? 'badge-status-processing text-danger' : ($product->stock <= 20 ? 'badge-status-lowstock' : 'badge-status-instock')); ?>">
                  <i class="bi bi-circle-fill" style="font-size: 0.45rem;"></i> <?php echo e($product->stock_status); ?>

                </span>
              </td>
              <td>
                <p class="mb-0 text-muted small" style="max-width: 260px; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;" title="<?php echo e($product->detail); ?>">
                  <?php echo e($product->detail ?: 'No detailed botanical description provided.'); ?>

                </p>
              </td>
              <td>
                <?php if($product->meta_title): ?>
                  <div class="d-flex align-items-center gap-1 text-success small fw-semibold" title="<?php echo e($product->meta_title); ?>">
                    <i class="bi bi-check-circle-fill"></i> SEO Configured
                  </div>
                <?php else: ?>
                  <div class="text-muted small"><i class="bi bi-dash-circle"></i> No Meta</div>
                <?php endif; ?>
                <?php if($product->og_image): ?>
                  <a href="<?php echo e($product->og_image_url); ?>" target="_blank" class="badge bg-light text-primary border text-decoration-none mt-1 d-inline-block small">
                    <i class="bi bi-image me-1"></i> OG Image
                  </a>
                <?php endif; ?>
              </td>
              <td class="text-end">
                <div class="d-inline-flex gap-1">
                  <button type="button" class="action-btn-sm" onclick="openEditProductModal(<?php echo e($product->id); ?>)" title="Edit Product">
                    <i class="bi bi-pencil-square"></i>
                  </button>
                  <button type="button" class="action-btn-sm btn-delete" onclick="deleteProduct(<?php echo e($product->id); ?>, '<?php echo e(addslashes($product->name)); ?>')" title="Delete Product">
                    <i class="bi bi-trash3"></i>
                  </button>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center py-5 text-muted">
                <i class="bi bi-box-seam fs-1 d-block mb-2 text-secondary"></i>
                No products found in the catalog. Click "Add New Product" to create your first formulation!
              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/pages/products.blade.php ENDPATH**/ ?>