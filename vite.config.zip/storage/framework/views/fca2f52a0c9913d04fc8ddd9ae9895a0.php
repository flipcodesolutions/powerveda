<!-- Sticky Header (Deep Navy #061E43) -->
<header class="site-header" id="siteHeader">
  <nav class="navbar" id="mainNavbar">
    <div class="container-custom w-100 d-flex align-items-center justify-content-between">

      <!-- Power Veda Logo & Tagline -->
      <div class="d-flex align-items-center">
        <a class="brand-logo" href="<?php echo e(route('home')); ?>" aria-label="Power Veda Home">
          <img src="<?php echo e(asset('image/logo.png')); ?>" alt="Power Veda Logo" width="220" height="50">
        </a>
        <div class="brand-tagline-wrap d-none d-sm-flex flex-column ps-3 ms-2 border-start"
          style="border-color: rgba(216, 188, 141, 0.4) !important;">
          <span class="brand-tagline-title"
            style="color: var(--gold-color); font-size: 0.76rem; font-weight: 700; text-transform: uppercase; letter-spacing: 1.2px; line-height: 1.2;">
            Power Veda's
          </span>
          <span class="brand-tagline-sub"
            style="color: var(--white-color); font-size: 0.84rem; font-weight: 800; letter-spacing: 0.6px; line-height: 1.15;">
            Strength &amp; Vitality
          </span>
        </div>
      </div>

      <!-- Desktop Navigation Links (Visible on Large Screens >= 992px) -->
      <div class="d-none d-lg-flex justify-content-center">
        <ul class="navbar-nav flex-row gap-1 mb-0">
          <li class="nav-item">
            <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>#home">Home</a>
          </li>
          <?php if((isset($products) ? $products->count() : \App\Models\Product::count()) > 1): ?>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(route('home')); ?>#shop">Shop</a>
            </li>
          <?php endif; ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>#why-us">Why Power Veda</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>#about">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>#reviews">Reviews</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('home')); ?>#contact">Contact</a>
          </li>
        </ul>
      </div>

      <!-- Desktop Action Buttons (Account, Orders, Wishlist & Cart - visible on desktop) -->
      <div class="nav-actions d-none d-lg-flex">
        <button type="button" class="action-btn-gold" data-bs-toggle="modal" data-bs-target="#authModal"
          aria-label="Sign In or Register" title="Account / Sign In" id="desktop-account-btn">
          <i class="bi bi-person"></i>
        </button>
        <button type="button" class="action-btn-gold <?php echo e(auth()->check() ? '' : 'd-none'); ?>" data-bs-toggle="modal" data-bs-target="#myOrdersModal"
          aria-label="My Orders" title="My Orders" id="desktop-orders-btn">
          <i class="bi bi-box-seam"></i>
        </button>
        <button type="button" class="action-btn-gold" data-bs-toggle="offcanvas" data-bs-target="#wishlistOffcanvas"
          aria-controls="wishlistOffcanvas" aria-label="View Wishlist" title="Wishlist">
          <i class="bi bi-heart"></i>
          <span class="badge-counter badge-wishlist-val">0</span>
        </button>
        <button type="button" class="action-btn-gold" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas"
          aria-controls="cartOffcanvas" aria-label="View Cart" title="Cart">
          <i class="bi bi-bag"></i>
          <span class="badge-counter badge-cart-val">0</span>
        </button>
      </div>

      <!-- Mobile Header Controls (Visible on Mobile/Tablet < 992px) -->
      <div class="d-flex d-lg-none align-items-center gap-2">
        <!-- Quick Cart Button on Mobile -->
        <button type="button" class="action-btn-gold" data-bs-toggle="offcanvas" data-bs-target="#cartOffcanvas"
          aria-controls="cartOffcanvas" aria-label="View Cart" title="Cart">
          <i class="bi bi-bag"></i>
          <span class="badge-counter badge-cart-val">0</span>
        </button>

        <!-- Luxury Offcanvas Mobile Drawer Trigger Button -->
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileNavDrawer"
          aria-controls="mobileNavDrawer" aria-label="Open Mobile Navigation">
          <i class="bi bi-list fs-4"></i>
        </button>
      </div>

    </div>
  </nav>
</header>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/visitor/partials/header.blade.php ENDPATH**/ ?>