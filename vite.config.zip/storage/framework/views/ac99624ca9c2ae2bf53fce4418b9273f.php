<!-- My Orders & Tracking Modal -->
<div class="modal fade" id="myOrdersModal" tabindex="-1" aria-labelledby="myOrdersModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg overflow-hidden rounded-3">

      <!-- Header -->
      <div class="orders-modal-header d-flex justify-content-between align-items-center">
        <div class="d-flex align-items-center gap-2">
          <i class="bi bi-box-seam fs-4" style="color: var(--gold-color);"></i>
          <div>
            <h5 class="modal-title mb-0 fw-bold" id="myOrdersModalLabel">My Orders &amp; Delivery Status</h5>
            <span class="small" style="color: var(--silver-color);">Track active shipments, view invoices &amp; reorder easily</span>
          </div>
        </div>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <!-- Body -->
      <div class="modal-body p-4" id="orders-modal-body">

        <!-- Order Card 1: Delivered -->
        <div class="order-card">
          <div class="order-card-header">
            <div>
              <span class="order-id-tag">#PV-94821</span>
              <span class="order-date-text ms-2">&bull; Placed on 22 Aug 2026</span>
            </div>
            <span class="badge bg-success py-2 px-3">
              <i class="bi bi-check-circle-fill me-1"></i> Delivered (24 Aug)
            </span>
          </div>

          <div class="order-card-body">
            <!-- Item 1 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="Ashwagandha Gold" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Ashwagandha Gold KSM-66</div>
                <div class="order-product-meta">Qty: 1 &bull; 60 Veg Capsules &bull; Organic KSM-66</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹1,499</div>
            </div>

            <!-- Item 2 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-2.jpg')); ?>" alt="Himalayan Detox Elixir" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Himalayan Detox Elixir</div>
                <div class="order-product-meta">Qty: 1 &bull; 100g Botanical Blend &bull; Tulsi &amp; Lemongrass</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹899</div>
            </div>

            <!-- Item 3 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-7.jpg')); ?>" alt="Neem &amp; Tulsi Cleanse" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Neem &amp; Tulsi Purifying Cleanse</div>
                <div class="order-product-meta">Qty: 1 &bull; 150ml Gentle Foaming Cleanser</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹699</div>
            </div>
          </div>

          <div class="order-card-footer">
            <div>
              <span class="text-muted small">Total Paid:</span>
              <span class="order-total-price ms-1">₹3,097</span>
              <span class="badge bg-light text-dark border ms-2">Prepaid UPI</span>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-secondary"
                onclick="showToast('Downloading Tax Invoice for #PV-94821...', 'info')">
                <i class="bi bi-file-earmark-arrow-down"></i> Invoice
              </button>
              <button class="btn btn-sm btn-primary" onclick="reorderItems([1, 2, 7])">
                <i class="bi bi-arrow-repeat"></i> Buy Again
              </button>
            </div>
          </div>
        </div>

        <!-- Order Card 2: In Transit -->
        <div class="order-card">
          <div class="order-card-header">
            <div>
              <span class="order-id-tag">#PV-95304</span>
              <span class="order-date-text ms-2">&bull; Placed on 25 Aug 2026</span>
            </div>
            <span class="badge bg-warning text-dark py-2 px-3">
              <i class="bi bi-truck me-1"></i> Out for Delivery Today
            </span>
          </div>

          <div class="order-card-body">
            <!-- Item 1 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-3.jpg')); ?>" alt="24K Saffron Elixir" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda 24K Saffron Radiance Elixir</div>
                <div class="order-product-meta">Qty: 1 &bull; 30ml Pure Kumkumadi Formulation</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹2,499</div>
            </div>

            <!-- Item 2 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-6.jpg')); ?>" alt="Turmeric Curcumin 95%" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Turmeric Curcumin 95%</div>
                <div class="order-product-meta">Qty: 1 &bull; 60 Capsules &bull; with BioPerine</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹1,299</div>
            </div>
          </div>

          <div class="order-card-footer">
            <div>
              <span class="text-muted small">Total Paid:</span>
              <span class="order-total-price ms-1">₹3,798</span>
              <span class="badge bg-light text-dark border ms-2">Free Express Shipping</span>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-secondary"
                onclick="showToast('BlueDart Express AWB #84920482: Out for delivery in Mumbai. Expected before 6:00 PM.', 'info')">
                <i class="bi bi-geo-alt-fill text-warning"></i> Track Courier
              </button>
              <button class="btn btn-sm btn-primary" onclick="reorderItems([3, 6])">
                <i class="bi bi-arrow-repeat"></i> Buy Again
              </button>
            </div>
          </div>
        </div>

        <!-- Order Card 3: Delivered -->
        <div class="order-card">
          <div class="order-card-header">
            <div>
              <span class="order-id-tag">#PV-91054</span>
              <span class="order-date-text ms-2">&bull; Placed on 10 Aug 2026</span>
            </div>
            <span class="badge bg-success py-2 px-3">
              <i class="bi bi-check-circle-fill me-1"></i> Delivered (13 Aug)
            </span>
          </div>

          <div class="order-card-body">
            <!-- Item 1 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-4.jpg')); ?>" alt="Triphala Gut Vitality" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Triphala Gut Vitality</div>
                <div class="order-product-meta">Qty: 1 &bull; 60 Botanical Tablets &bull; Digestive Balance</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹799</div>
            </div>

            <!-- Item 2 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-5.jpg')); ?>" alt="Brahmi Mind Focus" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Brahmi Mind Focus Tonic</div>
                <div class="order-product-meta">Qty: 1 &bull; 200ml Cognitive Elixir &bull; Memory &amp; Clarity</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹1,199</div>
            </div>

            <!-- Item 3 -->
            <div class="order-product-row">
              <img src="<?php echo e(asset('image/products/product-8.jpg')); ?>" alt="Sweet Almond Oil" class="order-thumb">
              <div class="flex-grow-1">
                <div class="order-product-name">Power Veda Cold-Pressed Sweet Almond Oil</div>
                <div class="order-product-meta">Qty: 1 &bull; 100ml Pure Therapeutic Grade Oil</div>
              </div>
              <div class="fw-bold" style="color: var(--heading-color);">₹999</div>
            </div>
          </div>

          <div class="order-card-footer">
            <div>
              <span class="text-muted small">Total Paid:</span>
              <span class="order-total-price ms-1">₹2,997</span>
              <span class="badge bg-light text-dark border ms-2">Prepaid Card</span>
            </div>
            <div class="d-flex gap-2">
              <button class="btn btn-sm btn-outline-secondary"
                onclick="showToast('Downloading Tax Invoice for #PV-91054...', 'info')">
                <i class="bi bi-file-earmark-arrow-down"></i> Invoice
              </button>
              <button class="btn btn-sm btn-primary" onclick="reorderItems([4, 5, 8])">
                <i class="bi bi-arrow-repeat"></i> Buy Again
              </button>
            </div>
          </div>
        </div>

      </div>

    </div>
  </div>
</div>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/visitor/partials/orders-modal.blade.php ENDPATH**/ ?>