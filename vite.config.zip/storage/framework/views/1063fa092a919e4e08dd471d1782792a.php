<!-- MODAL: ADD REVIEW MODAL -->
<div class="modal fade" id="reviewModal" tabindex="-1" aria-labelledby="reviewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-lg rounded-3">
      <div class="modal-header text-white" style="background-color: #061E43 !important;">
        <h5 class="modal-title fw-bold" id="reviewModalLabel">Add Verified Customer Review</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form id="review-form" onsubmit="handleReviewFormSubmit(event)">
        <div class="modal-body p-4">
          <div class="mb-3">
            <label class="form-label fw-bold small">Customer Name</label>
            <input type="text" class="form-control" id="rev-author" placeholder="e.g. Meera Joshi" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small">City / Location</label>
            <input type="text" class="form-control" id="rev-location" placeholder="e.g. Pune, Maharashtra" required>
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small">Product</label>
            <select class="form-select" id="rev-product">
              <option value="Power Veda Ashwagandha Gold KSM-66">Power Veda Ashwagandha Gold KSM-66</option>
              <option value="Power Veda 24K Saffron Radiance Elixir">Power Veda 24K Saffron Radiance Elixir</option>
              <option value="Power Veda Himalayan Detox Elixir">Power Veda Himalayan Detox Elixir</option>
              <option value="Power Veda Turmeric Curcumin 95%">Power Veda Turmeric Curcumin 95%</option>
              <option value="Power Veda Brahmi Mind Focus Tonic">Power Veda Brahmi Mind Focus Tonic</option>
              <option value="Power Veda Triphala Gut Vitality">Power Veda Triphala Gut Vitality</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small">Star Rating</label>
            <select class="form-select" id="rev-rating">
              <option value="5">⭐⭐⭐⭐⭐ (5 Stars - Exceptional)</option>
              <option value="4">⭐⭐⭐⭐ (4 Stars - Very Good)</option>
              <option value="3">⭐⭐⭐ (3 Stars - Average)</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small">Customer Feedback &amp; Review</label>
            <textarea class="form-control" id="rev-comment" rows="3" placeholder="Enter customer quote..." required></textarea>
          </div>
        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4">Publish Review</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/partials/review-modal.blade.php ENDPATH**/ ?>