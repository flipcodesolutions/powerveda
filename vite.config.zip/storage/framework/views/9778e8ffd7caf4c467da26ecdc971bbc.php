<?php $__env->startSection('page_title', 'Customer Orders & Shipments'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-tab-content" id="tab-orders">
  <div class="admin-panel-card">
    <div class="admin-panel-header">
      <div class="d-flex align-items-center gap-3 flex-wrap">
        <h3 class="admin-panel-title">Customer Orders &amp; Shipments</h3>
        <div class="admin-search-input">
          <i class="bi bi-search"></i>
          <input type="text" id="admin-order-search" placeholder="Search Order ID, Name, Phone...">
        </div>
      </div>
      <div class="btn-group btn-group-sm">
        <button class="btn btn-outline-secondary active" onclick="renderOrdersTable('all')">All</button>
        <button class="btn btn-outline-secondary" onclick="renderOrdersTable('In Transit')">In Transit</button>
        <button class="btn btn-outline-secondary" onclick="renderOrdersTable('Delivered')">Delivered</button>
        <button class="btn btn-outline-secondary" onclick="renderOrdersTable('Processing')">Processing</button>
      </div>
    </div>

    <div class="table-responsive">
      <table class="table admin-table">
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Date Placed</th>
            <th>Items</th>
            <th>Total (₹)</th>
            <th>Status</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody id="orders-table-body">
          <!-- Rendered dynamically by js/admin.js -->
        </tbody>
      </table>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/pages/orders.blade.php ENDPATH**/ ?>