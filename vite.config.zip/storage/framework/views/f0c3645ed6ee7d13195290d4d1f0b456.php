<!-- Admin Topbar -->
<header class="admin-topbar">
  <div class="d-flex align-items-center gap-3">
    <button type="button" class="admin-mobile-toggle" id="admin-mobile-toggle" aria-label="Toggle Sidebar">
      <i class="bi bi-list"></i>
    </button>
    <h1 class="admin-topbar-title" id="admin-topbar-title"><?php echo $__env->yieldContent('page_title', 'Dashboard Overview'); ?></h1>
  </div>

  <div class="admin-topbar-actions d-flex align-items-center gap-3">
    <div class="admin-user-pill">
      <div class="admin-user-avatar">
        <?php echo e(strtoupper(substr(auth()->user()->name ?? 'PV', 0, 2))); ?>

      </div>
      <div>
        <span class="d-block fw-bold" style="font-size: 0.85rem; color: #061E43;">
          <?php echo e(auth()->user()->name ?? 'Admin HQ'); ?>

        </span>
        <span class="d-block text-muted" style="font-size: 0.72rem;">
          <?php echo e(auth()->user()->role ?? 'Admin'); ?> (<?php echo e(auth()->user()->email ?? 'admin@powerveda.com'); ?>)
        </span>
      </div>
    </div>

    <!-- Sign Out Form -->
    <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-inline">
      <?php echo csrf_field(); ?>
      <button type="submit" class="btn btn-sm btn-outline-danger d-flex align-items-center gap-1" title="Sign Out">
        <i class="bi bi-box-arrow-right"></i>
        <span class="d-none d-sm-inline">Sign Out</span>
      </button>
    </form>
  </div>
</header>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/partials/topbar.blade.php ENDPATH**/ ?>