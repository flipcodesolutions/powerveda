<?php $__env->startSection('page_title', 'Customer Reviews & Testimonials'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-tab-content" id="tab-reviews">
  <div class="admin-panel-card">
    <div class="admin-panel-header">
      <h3 class="admin-panel-title">Customer Testimonials &amp; Reviews</h3>
      <button class="btn btn-primary" onclick="openAddReviewModal()">
        <i class="bi bi-plus-lg me-1"></i> Add Review
      </button>
    </div>

    <div class="table-responsive">
      <table class="table admin-table">
        <thead>
          <tr>
            <th>Reviewer</th>
            <th>Rating &amp; Feedback</th>
            <th>Formulation</th>
            <th>Date</th>
            <th>Status</th>
            <th class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody id="reviews-table-body">
          <!-- Rendered dynamically by js/admin.js -->
        </tbody>
      </table>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/pages/reviews.blade.php ENDPATH**/ ?>