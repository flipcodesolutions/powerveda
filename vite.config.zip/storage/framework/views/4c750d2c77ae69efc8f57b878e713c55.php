<?php $__env->startSection('title', 'Power Veda - Premium Wellness, Strength & Vitality'); ?>
<?php $__env->startSection('meta_description', 'Discover Power Veda: Premium wellness formulations designed to support strength, vitality, and a healthier lifestyle. 100% natural, pure, and trustworthy.'); ?>
<?php $__env->startSection('meta_keywords', 'Power Veda, wellness, strength, vitality, natural, Ayurvedic, health supplements, pure formulations'); ?>

<?php $__env->startSection('content'); ?>
<!-- 1. Hero Section (Deep Navy with Gold Accents) -->
<section class="hero-section" id="home">
  <div class="container-custom">
    <div class="row align-items-center">

      <div class="col-lg-7">
        <div class="hero-tag">
          <i class="bi bi-award-fill"></i> POWER &bull; STRENGTH &bull; WELLNESS &bull; VITALITY
        </div>
        <h1 class="hero-title">
          Strength &amp; <span class="gold-text">Vitality</span>
        </h1>
        <p class="hero-subtitle">
          Premium wellness products designed to support a stronger, healthier, and balanced lifestyle through pure
          natural botanicals and sacred Vedic science.
        </p>
        <div class="hero-cta-group">
          <a href="#shop" class="btn btn-primary">
            <i class="bi bi-bag-check-fill"></i> SHOP NOW
          </a>
          <a href="#about" class="btn btn-wellness">
            <i class="bi bi-flower1"></i> OUR PHILOSOPHY
          </a>
        </div>
        <div class="hero-trust-bar">
          <div class="hero-trust-item">
            <i class="bi bi-shield-fill-check"></i> 100% Certified Pure
          </div>
          <div class="hero-trust-item">
            <i class="bi bi-truck"></i> Express Nationwide Delivery
          </div>
          <div class="hero-trust-item">
            <i class="bi bi-patch-check-fill"></i> Third-Party Lab Verified
          </div>
        </div>
      </div>

      <div class="col-lg-5 d-none d-lg-block">
        <div class="hero-product-card">
          <img src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="Power Veda Ashwagandha Gold" class="hero-product-img">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <span class="badge-natural">[ NATURAL KSM-66 ]</span>
            <div class="stars text-warning small">
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
              <i class="bi bi-star-fill"></i>
            </div>
          </div>
          <h4 class="fw-bold mb-1" style="font-size: 1.15rem; color: var(--heading-color);">Power Veda Ashwagandha Gold</h4>
          <p class="text-muted small mb-3">Pure root extract designed for peak physical endurance and vitality.</p>
          <div class="d-flex justify-content-between align-items-center">
            <div>
              <span class="fw-bold fs-5" style="color: var(--heading-color);">₹1,499</span>
              <span class="text-muted text-decoration-line-through small ms-1">₹1,999</span>
            </div>
            <button class="btn btn-sm btn-primary" onclick="addToCart(1)">
              <i class="bi bi-plus-lg"></i> Quick Add
            </button>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- 2. Why Choose Power Veda (4 Feature Cards) -->
<section class="why-choose-section" id="why-us" aria-label="Why Choose Power Veda">
  <div class="container-custom">
    <div class="section-header">
      <span class="section-tag tag-wellness">Our Foundations</span>
      <h2 class="section-title">Why Choose Power Veda</h2>
      <p class="section-desc">Every Power Veda formulation is guided by four foundational pillars of authentic health and enduring vitality.</p>
    </div>

    <div class="row g-4">

      <!-- Strength -->
      <div class="col-12 col-sm-6 col-lg-3">
        <div class="why-feature-card">
          <div class="why-icon-circle icon-gold">
            <i class="bi bi-lightning-charge"></i>
          </div>
          <h3 class="why-card-title">Strength</h3>
          <p class="why-card-desc">Quality products formulated with care to support physical resilience, stamina, and daily energy.</p>
        </div>
      </div>

      <!-- Natural -->
      <div class="col-12 col-sm-6 col-lg-3">
        <div class="why-feature-card">
          <div class="why-icon-circle icon-green">
            <i class="bi bi-flower1"></i>
          </div>
          <h3 class="why-card-title">Natural</h3>
          <p class="why-card-desc">Focused on wellness and natural botanicals, strictly free from synthetic chemicals or artificial fillers.</p>
        </div>
      </div>

      <!-- Trusted -->
      <div class="col-12 col-sm-6 col-lg-3">
        <div class="why-feature-card">
          <div class="why-icon-circle icon-silver">
            <i class="bi bi-shield-check"></i>
          </div>
          <h3 class="why-card-title">Trusted</h3>
          <p class="why-card-desc">A brand customers rely on for authentic Vedic integrity, precision extraction, and proven safety.</p>
        </div>
      </div>

      <!-- Vitality -->
      <div class="col-12 col-sm-6 col-lg-3">
        <div class="why-feature-card">
          <div class="why-icon-circle icon-gold">
            <i class="bi bi-heart-pulse"></i>
          </div>
          <h3 class="why-card-title">Vitality</h3>
          <p class="why-card-desc">Holistic formulations designed to nourish mind, body, and soul for an active, healthier lifestyle.</p>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- 3. Product Section (Unified Product Catalog) -->
<section class="products-section" id="shop">
  <div class="container-custom">

    <div class="section-header">
      <span class="section-tag">Pure Formulations</span>
      <h2 class="section-title">The Power Veda Range</h2>
      <p class="section-desc">Handcrafted formulas engineered for maximum bio-potency, third-party lab tested, and 100% natural.</p>
    </div>

    <!-- Search Toolbar -->
    <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-bottom flex-wrap gap-3">
      <div class="fw-bold" style="color: var(--heading-color);">
        <i class="bi bi-grid-fill text-warning me-1"></i> All Formulations (8 Items)
      </div>
      <div class="product-search-box">
        <i class="bi bi-search"></i>
        <input type="text" id="product-search" placeholder="Search formulations..." aria-label="Search products">
      </div>
    </div>

    <!-- Product Cards Grid (Static Semantic HTML) -->
    <div class="row" id="products-grid">

      <!-- Product 1 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Ashwagandha Gold KSM-66" data-badge="NATURAL">
        <div class="product-card" data-id="1">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="Power Veda Ashwagandha Gold KSM-66" loading="lazy">
            <span class="badge-natural">[ NATURAL ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(1)" id="wishlist-btn-1"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(1)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(1)">Power Veda Ashwagandha Gold KSM-66</h3>
            <p class="product-description">Premium full-spectrum organic root extract designed to boost physical
              vitality, reduce stress, and enhance muscle endurance.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
              </span>
              <span class="text-muted small">(240)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹1,499</span>
              <span class="price-original">₹1,999</span>
              <span class="price-badge-gold">25% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(1)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 2 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Himalayan Detox Elixir" data-badge="100% PURE">
        <div class="product-card" data-id="2">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-2.jpg')); ?>" alt="Power Veda Himalayan Detox Elixir" loading="lazy">
            <span class="badge-natural">[ 100% PURE ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(2)" id="wishlist-btn-2"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(2)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(2)">Power Veda Himalayan Detox Elixir</h3>
            <p class="product-description">Handcrafted botanical blend of holy tulsi, lemongrass, and antioxidant
              herbs for cellular rejuvenation and daily detox.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-half"></i>
              </span>
              <span class="text-muted small">(135)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹899</span>
              <span class="price-original">₹1,199</span>
              <span class="price-badge-gold">25% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(2)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 3 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda 24K Saffron Radiance Elixir" data-badge="PREMIUM">
        <div class="product-card" data-id="3">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-3.jpg')); ?>" alt="Power Veda 24K Saffron Radiance Elixir" loading="lazy">
            <span class="badge-natural">[ PREMIUM ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(3)" id="wishlist-btn-3"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(3)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(3)">Power Veda 24K Saffron Radiance Elixir</h3>
            <p class="product-description">Sacred facial and skin radiance elixir formulated with pure Kashmiri
              saffron, sandalwood, and lotus blossoms.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
              </span>
              <span class="text-muted small">(310)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹2,499</span>
              <span class="price-original">₹3,299</span>
              <span class="price-badge-gold">24% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(3)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 4 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Triphala Gut Vitality" data-badge="VITALITY">
        <div class="product-card" data-id="4">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-4.jpg')); ?>" alt="Power Veda Triphala Gut Vitality" loading="lazy">
            <span class="badge-natural">[ VITALITY ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(4)" id="wishlist-btn-4"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(4)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(4)">Power Veda Triphala Gut Vitality</h3>
            <p class="product-description">Time-tested three-fruit botanical formula supporting digestion, nutrient
              absorption, and body purification.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-half"></i>
              </span>
              <span class="text-muted small">(95)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹799</span>
              <span class="price-original">₹999</span>
              <span class="price-badge-gold">20% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(4)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 5 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Brahmi Mind Focus Tonic" data-badge="STRENGTH">
        <div class="product-card" data-id="5">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-5.jpg')); ?>" alt="Power Veda Brahmi Mind Focus Tonic" loading="lazy">
            <span class="badge-natural">[ STRENGTH ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(5)" id="wishlist-btn-5"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(5)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(5)">Power Veda Brahmi Mind Focus Tonic</h3>
            <p class="product-description">Cognitive enhancement formulation supporting peak memory clarity, sharp
              focus, and nervous system health.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
              </span>
              <span class="text-muted small">(160)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹1,199</span>
              <span class="price-original">₹1,599</span>
              <span class="price-badge-gold">25% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(5)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 6 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Turmeric Curcumin 95%" data-badge="IMMUNITY">
        <div class="product-card" data-id="6">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-6.jpg')); ?>" alt="Power Veda Turmeric Curcumin 95%" loading="lazy">
            <span class="badge-natural">[ IMMUNITY ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(6)" id="wishlist-btn-6"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(6)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(6)">Power Veda Turmeric Curcumin 95%</h3>
            <p class="product-description">Ultra-potent golden turmeric extract formulated with BioPerine for joint
              flexibility, vitality, and robust immunity.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
              </span>
              <span class="text-muted small">(215)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹1,299</span>
              <span class="price-original">₹1,699</span>
              <span class="price-badge-gold">23% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(6)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 7 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Neem & Tulsi Purifying Cleanse" data-badge="WELLNESS">
        <div class="product-card" data-id="7">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-7.jpg')); ?>" alt="Power Veda Neem & Tulsi Purifying Cleanse" loading="lazy">
            <span class="badge-natural">[ WELLNESS ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(7)" id="wishlist-btn-7"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(7)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(7)">Power Veda Neem &amp; Tulsi Purifying Cleanse</h3>
            <p class="product-description">Gentle soap-free foaming wash that balances natural skin oils and deeply
              purifies pores with sacred botanicals.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-half"></i>
              </span>
              <span class="text-muted small">(112)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹699</span>
              <span class="price-original">₹899</span>
              <span class="price-badge-gold">22% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(7)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

      <!-- Product 8 -->
      <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 product-item-col"
        data-title="Power Veda Cold-Pressed Sweet Almond Oil" data-badge="COLD PRESSED">
        <div class="product-card" data-id="8">
          <div class="product-img-wrapper">
            <img src="<?php echo e(asset('image/products/product-8.jpg')); ?>" alt="Power Veda Cold-Pressed Sweet Almond Oil" loading="lazy">
            <span class="badge-natural">[ COLD PRESSED ]</span>
            <div class="product-card-actions">
              <button type="button" class="btn-card-action" onclick="toggleWishlist(8)" id="wishlist-btn-8"
                title="Add to Wishlist">
                <i class="bi bi-heart"></i>
              </button>
              <button type="button" class="btn-card-action" onclick="openQuickView(8)" title="Quick View">
                <i class="bi bi-eye"></i>
              </button>
            </div>
          </div>

          <div class="product-content">
            <h3 class="product-title" onclick="openQuickView(8)">Power Veda Cold-Pressed Sweet Almond Oil</h3>
            <p class="product-description">100% unrefined therapeutic oil rich in natural Vitamin E, perfect for
              restorative body massage and muscle recovery.</p>

            <div class="product-rating">
              <span class="stars">
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
                <i class="bi bi-star-fill"></i>
              </span>
              <span class="text-muted small">(180)</span>
            </div>

            <div class="product-pricing-wrap">
              <span class="price-discounted">₹999</span>
              <span class="price-original">₹1,299</span>
              <span class="price-badge-gold">23% OFF</span>
            </div>

            <button type="button" class="btn-add-cart" onclick="addToCart(8)">
              <i class="bi bi-bag-plus"></i> ADD TO CART
            </button>
          </div>
        </div>
      </div>

    </div>

  </div>
</section>

<!-- 4. Promotional Section (Deep Navy + Royal Blue + Gold + White) -->
<section class="promotional-section" aria-label="Special Promotion">
  <div class="container-custom">
    <div class="promo-inner">
      <div class="row align-items-center">
        <div class="col-lg-8">
          <span class="promo-tag">⭐ LIMITED TIME OFFER</span>
          <h2 class="promo-title">PREMIUM WELLNESS COLLECTION</h2>
          <p class="promo-subtitle">
            Discover products designed for strength, vitality and wellness. Enjoy exclusive seasonal pricing and free
            botanical gifts with your order.
          </p>

          <!-- Real-time Deal Countdown Timer -->
          <div class="countdown-box">
            <div class="countdown-unit">
              <span class="countdown-num" id="timer-hours">14</span>
              <span class="countdown-lbl">Hours</span>
            </div>
            <div class="countdown-unit">
              <span class="countdown-num" id="timer-minutes">30</span>
              <span class="countdown-lbl">Mins</span>
            </div>
            <div class="countdown-unit">
              <span class="countdown-num" id="timer-seconds">00</span>
              <span class="countdown-lbl">Secs</span>
            </div>
          </div>

          <div class="d-flex flex-wrap align-items-center gap-3">
            <a href="#shop" class="btn btn-primary">
              <i class="bi bi-lightning-fill"></i> EXPLORE NOW
            </a>
            <a href="#about" class="btn btn-outline-gold">
              OUR PHILOSOPHY
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 5. About Power Veda Section (White Background with Subtle Gold/Green Accents) -->
<section class="about-section" id="about">
  <div class="container-custom">
    <div class="row align-items-center g-5">

      <div class="col-lg-6">
        <div class="about-visual-wrap">
          <img src="<?php echo e(asset('image/about.jpg')); ?>" alt="Power Veda Botanical Preparation" class="about-img" loading="lazy">
          <div class="about-heritage-badge">
            <div class="about-badge-number">100%</div>
            <div class="about-badge-label">Natural &amp; Trusted</div>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <span class="section-tag tag-wellness">About Power Veda</span>
        <h2 class="section-title text-start mb-3">Ancient Wisdom Engineered for Modern Strength</h2>
        <p class="text-muted mb-4">
          Power Veda was founded on the unyielding principle that true human vitality stems from harmonious alignment
          with nature. We unite classical Vedic knowledge with advanced modern extraction standards to deliver
          unparalleled purity and effectiveness.
        </p>

        <ul class="about-philosophy-list">
          <li class="about-philosophy-item">
            <i class="bi bi-shield-fill-check"></i>
            <div>
              <strong style="color: var(--heading-color);">Strength &amp; Cellular Vitality</strong>
              <p class="text-muted small mb-0">High-potency adaptogens formulated to increase physical energy, focus, and resilience.</p>
            </div>
          </li>
          <li class="about-philosophy-item">
            <i class="bi bi-flower1"></i>
            <div>
              <strong style="color: var(--heading-color);">Wildcrafted &amp; Ethically Sourced</strong>
              <p class="text-muted small mb-0">Partnering directly with sustainable Himalayan organic cultivators with fair-trade ethics.</p>
            </div>
          </li>
          <li class="about-philosophy-item">
            <i class="bi bi-award-fill"></i>
            <div>
              <strong style="color: var(--heading-color);">Gold-Standard Quality &amp; Testing</strong>
              <p class="text-muted small mb-0">Every batch is certified by independent laboratories for active botanical bio-markers.</p>
            </div>
          </li>
        </ul>

        <a href="#shop" class="btn btn-secondary">
          DISCOVER OUR PRODUCTS <i class="bi bi-arrow-right ms-1"></i>
        </a>
      </div>

    </div>
  </div>
</section>

<!-- 6. Customer Reviews Section -->
<section class="reviews-section" id="reviews" aria-label="Customer Testimonials">
  <div class="container-custom">

    <div class="section-header">
      <span class="section-tag">Testimonials</span>
      <h2 class="section-title">Trusted by Thousands Across the Country</h2>
      <p class="section-desc">Read genuine experiences from individuals who have integrated Power Veda into their daily wellness journey.</p>
    </div>

    <div class="row g-4">

      <!-- Review 1 -->
      <div class="col-12 col-md-4">
        <div class="review-card">
          <div class="review-stars">
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
          </div>
          <p class="review-quote">
            "The Ashwagandha Gold capsules have been a game-changer for my daily stamina and recovery. I feel more
            energetic during workouts and deeply calm at night."
          </p>
          <div class="review-author">
            <img src="<?php echo e(asset('image/review-1.jpg')); ?>" alt="Aarohi Sharma" class="review-avatar" loading="lazy">
            <div>
              <h4 class="review-name">Aarohi Sharma</h4>
              <span class="review-verified">
                <i class="bi bi-patch-check-fill"></i> Verified Buyer &bull; Mumbai
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Review 2 -->
      <div class="col-12 col-md-4">
        <div class="review-card">
          <div class="review-stars">
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
          </div>
          <p class="review-quote">
            "Kumkumadi 24K Saffron Oil is pure luxury. The texture is lightweight, deeply nourishing, and gave my skin
            a healthy, vibrant glow within just two weeks."
          </p>
          <div class="review-author">
            <img src="<?php echo e(asset('image/review-2.jpg')); ?>" alt="Vikram Malhotra" class="review-avatar" loading="lazy">
            <div>
              <h4 class="review-name">Vikram Malhotra</h4>
              <span class="review-verified">
                <i class="bi bi-patch-check-fill"></i> Verified Buyer &bull; Bengaluru
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- Review 3 -->
      <div class="col-12 col-md-4">
        <div class="review-card">
          <div class="review-stars">
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
          </div>
          <p class="review-quote">
            "Super fast delivery, premium glass jar packaging, and authentic taste. The Himalayan Herbal Detox tea has
            replaced regular coffee in my morning routine."
          </p>
          <div class="review-author">
            <img src="<?php echo e(asset('image/review-3.jpg')); ?>" alt="Dr. Priya Nair" class="review-avatar" loading="lazy">
            <div>
              <h4 class="review-name">Dr. Priya Nair</h4>
              <span class="review-verified">
                <i class="bi bi-patch-check-fill"></i> Verified Buyer &bull; Delhi
              </span>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- 7. Newsletter Section (Deep Navy #061E43) -->
<section class="newsletter-section" aria-label="Stay Connected">
  <div class="container-custom">
    <div class="newsletter-card">
      <span class="section-tag mb-3">Power Veda Circle</span>
      <h2>Stay Connected With Power Veda</h2>
      <p>Get updates about new products, exclusive offers, and wellness collections designed for strength and longevity.</p>

      <form class="newsletter-form" id="newsletter-form" novalidate>
        <input type="email" class="newsletter-input" id="newsletter-email" placeholder="Enter your email address..."
          required aria-label="Email address">
        <button type="submit" class="btn btn-primary">
          SUBSCRIBE <i class="bi bi-send-fill ms-1"></i>
        </button>
      </form>
      <span class="small" style="color: var(--silver-color);">
        <i class="bi bi-lock-fill text-warning me-1"></i> We respect your privacy. No spam, unsubscribe anytime.
      </span>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/pages/home.blade.php ENDPATH**/ ?>