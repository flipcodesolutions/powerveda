<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo $__env->yieldContent('title', 'Power Veda - Premium Wellness, Strength & Vitality'); ?></title>
  <meta name="description" content="<?php echo $__env->yieldContent('meta_description', 'Discover Power Veda: Premium wellness formulations designed to support strength, vitality, and a healthier lifestyle. 100% natural, pure, and trustworthy.'); ?>">
  <meta name="keywords" content="<?php echo $__env->yieldContent('meta_keywords', 'Power Veda, wellness, strength, vitality, natural, Ayurvedic, health supplements, pure formulations'); ?>">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="<?php echo e(asset('image/logo.png')); ?>">

  <!-- Google Fonts: Playfair Display, Syne & Plus Jakarta Sans -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">

  <!-- Bootstrap 5 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

  <!-- Bootstrap Icons CDN -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <!-- Custom Brand Stylesheet -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body data-bs-spy="scroll" data-bs-target="#mainNavbar" data-bs-offset="90">

  <!-- Top Announcement Bar -->
  <?php echo $__env->make('partials.announcement', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Sticky Header Navigation -->
  <?php echo $__env->make('partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Main Content View -->
  <main>
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  <!-- Site Footer -->
  <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Mobile Offcanvas Drawer -->
  <?php echo $__env->make('partials.mobile-drawer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Cart Offcanvas Drawer -->
  <?php echo $__env->make('partials.cart-drawer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Wishlist Offcanvas Drawer -->
  <?php echo $__env->make('partials.wishlist-drawer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Authentication Modal -->
  <?php echo $__env->make('partials.auth-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- My Orders Modal -->
  <?php echo $__env->make('partials.orders-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Product Quick View Modal -->
  <?php echo $__env->make('partials.quick-view', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Toast Notification Container -->
  <div class="toast-container-custom" id="toast-container" aria-live="polite" aria-atomic="true"></div>

  <!-- Floating Back to Top Button -->
  <button type="button" class="back-to-top-btn" id="back-to-top" aria-label="Back to top">
    <i class="bi bi-arrow-up"></i>
  </button>

  <!-- Bootstrap 5 Bundle JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
    crossorigin="anonymous"></script>

  <!-- Custom JavaScript Logic -->
  <script src="<?php echo e(asset('js/script.js')); ?>"></script>
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/layouts/app.blade.php ENDPATH**/ ?>