<!-- MODAL: ADD / EDIT PRODUCT MODAL WITH FILE UPLOADS -->
<div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content border-0 shadow-lg rounded-3">
      <div class="modal-header text-white" style="background-color: #061E43 !important;">
        <h5 class="modal-title fw-bold" id="product-modal-title">
          <i class="bi bi-box-seam me-2 text-warning"></i>Product Details
        </h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <form id="product-form" method="POST" enctype="multipart/form-data" onsubmit="handleProductFormSubmit(event)">
        <?php echo csrf_field(); ?>
        <input type="hidden" id="edit-product-id" name="id" value="">
        <input type="hidden" id="form-method" name="_method" value="POST">

        <div class="modal-body p-4">
          <div class="row g-3">

            <!-- Section 1: Basic Information -->
            <div class="col-12">
              <h6 class="fw-bold text-uppercase pb-1 border-bottom" style="color: #061E43; font-size: 0.8rem; letter-spacing: 0.5px;">
                <i class="bi bi-info-circle me-1 text-primary"></i> 1. Basic Product Information
              </h6>
            </div>

            <div class="col-md-8">
              <label class="form-label fw-bold small" for="prod-name">Product Name <span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="prod-name" name="name" placeholder="e.g. Power Veda Ashwagandha Gold KSM-66" required>
            </div>

            <div class="col-md-4">
              <label class="form-label fw-bold small" for="prod-badge">Badge Tag</label>
              <input type="text" class="form-control" id="prod-badge" name="badge" placeholder="e.g. NATURAL, 100% PURE" value="NATURAL">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-bold small" for="prod-price">Sale Price (₹) <span class="text-danger">*</span></label>
              <input type="number" class="form-control" id="prod-price" name="price" placeholder="1499" required min="1" step="0.01">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-bold small" for="prod-original-price">Original / MRP (₹)</label>
              <input type="number" class="form-control" id="prod-original-price" name="original_price" placeholder="1999" min="1" step="0.01">
            </div>

            <div class="col-md-4">
              <label class="form-label fw-bold small" for="prod-stock">Stock Quantity <span class="text-danger">*</span></label>
              <input type="number" class="form-control" id="prod-stock" name="stock" placeholder="50" value="50" required min="0">
            </div>

            <!-- Section 2: Photo File Upload & Formulation Detail -->
            <div class="col-12 pt-2">
              <h6 class="fw-bold text-uppercase pb-1 border-bottom" style="color: #061E43; font-size: 0.8rem; letter-spacing: 0.5px;">
                <i class="bi bi-image me-1 text-primary"></i> 2. Product Photo &amp; Formulation Detail
              </h6>
            </div>

            <div class="col-md-8">
              <label class="form-label fw-bold small" for="prod-photo-input">
                Product Photo (File Upload)
              </label>
              <input type="file" class="form-control" id="prod-photo-input" name="photo" accept="image/*" onchange="previewProductPhoto(event)">
              <div class="form-text small">Accepted formats: JPG, PNG, WEBP, SVG (Max 5MB).</div>
            </div>

            <div class="col-md-4 d-flex flex-column align-items-center justify-content-center">
              <label class="form-label fw-bold small d-block mb-1">Photo Preview</label>
              <div class="border rounded p-1 bg-light text-center" style="width: 80px; height: 80px;">
                <img id="prod-photo-preview" src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="Photo Preview" style="width: 100%; height: 100%; object-fit: cover; border-radius: 6px;">
              </div>
            </div>

            <div class="col-12">
              <label class="form-label fw-bold small" for="prod-detail">Product Detail &amp; Botanical Description</label>
              <textarea class="form-control" id="prod-detail" name="detail" rows="3" placeholder="Describe the therapeutic benefits, Vedic ingredients, extraction methods, and usage instructions..."></textarea>
            </div>

            <!-- Section 3: SEO & Social Sharing (Meta Title, Meta Detail, OG Image) -->
            <div class="col-12 pt-2">
              <h6 class="fw-bold text-uppercase pb-1 border-bottom" style="color: #061E43; font-size: 0.8rem; letter-spacing: 0.5px;">
                <i class="bi bi-share me-1 text-primary"></i> 3. SEO Metadata &amp; OpenGraph (OG) Social Sharing
              </h6>
            </div>

            <div class="col-12">
              <label class="form-label fw-bold small" for="prod-meta-title">SEO Meta Title</label>
              <input type="text" class="form-control" id="prod-meta-title" name="meta_title" placeholder="e.g. Buy Organic Ashwagandha Gold KSM-66 | Power Veda Strength">
            </div>

            <div class="col-12">
              <label class="form-label fw-bold small" for="prod-meta-detail">SEO Meta Detail / Description</label>
              <textarea class="form-control" id="prod-meta-detail" name="meta_detail" rows="2" placeholder="Brief search engine meta snippet (150-160 characters recommended)..."></textarea>
            </div>

            <div class="col-md-8">
              <label class="form-label fw-bold small" for="prod-og-image-input">
                OpenGraph (OG) Social Share Image (File Upload)
              </label>
              <input type="file" class="form-control" id="prod-og-image-input" name="og_image" accept="image/*" onchange="previewOgImage(event)">
              <div class="form-text small">Upload image used when shared on WhatsApp, Facebook, Twitter (1200x630 recommended).</div>
            </div>

            <div class="col-md-4 d-flex flex-column align-items-center justify-content-center">
              <label class="form-label fw-bold small d-block mb-1">OG Image Preview</label>
              <div class="border rounded p-1 bg-light text-center" style="width: 100px; height: 60px;">
                <img id="prod-og-preview" src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="OG Preview" style="width: 100%; height: 100%; object-fit: cover; border-radius: 4px;">
              </div>
            </div>

          </div>
        </div>

        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary px-4" id="btn-save-product">
            <i class="bi bi-check-circle me-1"></i> Save Product
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/partials/product-modal.blade.php ENDPATH**/ ?>