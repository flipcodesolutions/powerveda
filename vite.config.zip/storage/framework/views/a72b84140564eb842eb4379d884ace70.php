<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Power Veda Admin Console. Manage botanical formulations, customer orders, and verified customer reviews.">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Admin Dashboard | Power Veda HQ</title>

  <!-- Favicon -->
  <link rel="icon" type="image/png" href="<?php echo e(asset('image/logo.png')); ?>">

  <!-- Google Fonts: Syne (Headings) & Plus Jakarta Sans (Body) -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Syne:wght@600;700;800&display=swap" rel="stylesheet">

  <!-- Bootstrap 5.3 CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

  <!-- Brand CSS & Admin Specific CSS -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>">
</head>

<body class="admin-body">

  <!-- 1. Admin Sidebar Navigation -->
  <aside class="admin-sidebar">
    <div class="admin-sidebar-brand">
      <img src="<?php echo e(asset('image/logo.png')); ?>" alt="Power Veda Logo">
      <div class="d-flex flex-column ps-2 border-start border-secondary">
        <span style="color: var(--gold-color, #D8BC8D); font-size: 0.72rem; font-weight: 800; text-transform: uppercase; letter-spacing: 1px;">Admin Console</span>
        <span style="color: #ffffff; font-size: 0.8rem; font-weight: 700;">HQ Management</span>
      </div>
    </div>

    <ul class="admin-nav-list">
      <li class="admin-nav-item">
        <a href="javascript:void(0)" class="admin-nav-link active" data-tab="overview" onclick="switchAdminTab('overview')">
          <div>
            <i class="bi bi-grid-1x2-fill nav-icon"></i>
            <span>Dashboard Overview</span>
          </div>
          <i class="bi bi-chevron-right small text-muted"></i>
        </a>
      </li>
      <li class="admin-nav-item">
        <a href="javascript:void(0)" class="admin-nav-link" data-tab="products" onclick="switchAdminTab('products')">
          <div>
            <i class="bi bi-box-seam-fill nav-icon"></i>
            <span>Manage Products</span>
          </div>
          <span class="badge bg-warning text-dark small" id="sidebar-prod-count">8</span>
        </a>
      </li>
      <li class="admin-nav-item">
        <a href="javascript:void(0)" class="admin-nav-link" data-tab="orders" onclick="switchAdminTab('orders')">
          <div>
            <i class="bi bi-bag-check-fill nav-icon"></i>
            <span>Customer Orders</span>
          </div>
          <span class="badge bg-success small">4</span>
        </a>
      </li>
      <li class="admin-nav-item">
        <a href="javascript:void(0)" class="admin-nav-link" data-tab="reviews" onclick="switchAdminTab('reviews')">
          <div>
            <i class="bi bi-star-fill nav-icon"></i>
            <span>Manage Reviews</span>
          </div>
          <i class="bi bi-chevron-right small text-muted"></i>
        </a>
      </li>
    </ul>

    <div class="admin-sidebar-footer">
      <a href="<?php echo e(route('home')); ?>" class="btn-storefront">
        <i class="bi bi-arrow-left"></i> View Live Storefront
      </a>
    </div>
  </aside>

  <!-- 2. Admin Main Content Wrapper -->
  <main class="admin-main">

    <!-- Topbar -->
    <header class="admin-topbar">
      <div class="d-flex align-items-center gap-3">
        <button type="button" class="admin-mobile-toggle" id="admin-mobile-toggle" aria-label="Toggle Sidebar">
          <i class="bi bi-list"></i>
        </button>
        <h1 class="admin-topbar-title" id="admin-topbar-title">Dashboard Overview</h1>
      </div>

      <div class="admin-topbar-actions">
        <div class="admin-user-pill">
          <div class="admin-user-avatar">PV</div>
          <div>
            <span class="d-block fw-bold" style="font-size: 0.85rem; color: #061E43;">Admin HQ</span>
            <span class="d-block text-muted" style="font-size: 0.72rem;">Store Manager</span>
          </div>
        </div>
      </div>
    </header>

    <!-- Admin Body Content Tabs -->
    <div class="admin-content">

      <!-- TAB 1: DASHBOARD OVERVIEW -->
      <section class="admin-tab-content" id="tab-overview">
        
        <!-- Metrics Row -->
        <div class="row g-3 mb-4">
          <div class="col-12 col-sm-6 col-xl-3">
            <div class="admin-stat-card stat-primary">
              <div>
                <div class="admin-stat-label">Total Revenue</div>
                <div class="admin-stat-val" id="stat-revenue">₹12,890</div>
                <div class="admin-stat-trend text-success"><i class="bi bi-graph-up-arrow"></i> +18.4% this month</div>
              </div>
              <div class="admin-stat-icon"><i class="bi bi-currency-rupee"></i></div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="admin-stat-card stat-success">
              <div>
                <div class="admin-stat-label">Total Orders</div>
                <div class="admin-stat-val" id="stat-orders">4</div>
                <div class="admin-stat-trend text-success"><i class="bi bi-truck"></i> 100% On-Time Delivery</div>
              </div>
              <div class="admin-stat-icon"><i class="bi bi-bag-check"></i></div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="admin-stat-card stat-gold">
              <div>
                <div class="admin-stat-label">Active Products</div>
                <div class="admin-stat-val" id="stat-products">8</div>
                <div class="admin-stat-trend" style="color: #735737;"><i class="bi bi-shield-check"></i> 100% Lab Tested</div>
              </div>
              <div class="admin-stat-icon"><i class="bi bi-box-seam"></i></div>
            </div>
          </div>

          <div class="col-12 col-sm-6 col-xl-3">
            <div class="admin-stat-card stat-info">
              <div>
                <div class="admin-stat-label">Customer Reviews</div>
                <div class="admin-stat-val" id="stat-reviews">4</div>
                <div class="admin-stat-trend text-primary"><i class="bi bi-star-fill text-warning"></i> 4.9 / 5.0 Average</div>
              </div>
              <div class="admin-stat-icon"><i class="bi bi-chat-heart"></i></div>
            </div>
          </div>
        </div>

        <!-- Quick Actions & Highlights -->
        <div class="row g-4 mb-4">
          <div class="col-12 col-lg-8">
            <div class="admin-panel-card mb-0">
              <div class="admin-panel-header">
                <h3 class="admin-panel-title">Recent Customer Orders</h3>
                <button class="btn btn-sm btn-outline-primary" onclick="switchAdminTab('orders')">View All Orders</button>
              </div>
              <div class="table-responsive">
                <table class="table admin-table">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer</th>
                      <th>Items</th>
                      <th>Total</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><strong style="color: #061E43;">#PV-94821</strong></td>
                      <td>Aarohi Sharma</td>
                      <td>3 Formulations</td>
                      <td><strong>₹3,097</strong></td>
                      <td><span class="badge-status badge-status-delivered">Delivered</span></td>
                    </tr>
                    <tr>
                      <td><strong style="color: #061E43;">#PV-95304</strong></td>
                      <td>Vikram Malhotra</td>
                      <td>2 Formulations</td>
                      <td><strong>₹3,798</strong></td>
                      <td><span class="badge-status badge-status-intransit">In Transit</span></td>
                    </tr>
                    <tr>
                      <td><strong style="color: #061E43;">#PV-91054</strong></td>
                      <td>Dr. Priya Nair</td>
                      <td>3 Formulations</td>
                      <td><strong>₹2,997</strong></td>
                      <td><span class="badge-status badge-status-delivered">Delivered</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="col-12 col-lg-4">
            <div class="admin-panel-card mb-0 h-100">
              <div class="admin-panel-header">
                <h3 class="admin-panel-title">Quick Management</h3>
              </div>
              <div class="p-3 d-flex flex-column gap-2">
                <button class="btn btn-primary w-100 py-2 d-flex align-items-center justify-content-center gap-2" onclick="openAddProductModal()">
                  <i class="bi bi-plus-circle-fill"></i> Add New Product
                </button>
                <button class="btn btn-outline-secondary w-100 py-2 d-flex align-items-center justify-content-center gap-2" onclick="switchAdminTab('orders')">
                  <i class="bi bi-truck"></i> Update Order Status
                </button>
                <button class="btn btn-outline-secondary w-100 py-2 d-flex align-items-center justify-content-center gap-2" onclick="openAddReviewModal()">
                  <i class="bi bi-star"></i> Post Customer Review
                </button>
              </div>
            </div>
          </div>
        </div>

      </section>

      <!-- TAB 2: PRODUCTS MANAGEMENT -->
      <section class="admin-tab-content" id="tab-products" style="display: none;">
        <div class="admin-panel-card">
          <div class="admin-panel-header">
            <div class="d-flex align-items-center gap-3 flex-wrap">
              <h3 class="admin-panel-title">Product Catalog (Power Veda Range)</h3>
              <div class="admin-search-input">
                <i class="bi bi-search"></i>
                <input type="text" id="admin-product-search" placeholder="Search formulations...">
              </div>
            </div>
            <button class="btn btn-primary" onclick="openAddProductModal()">
              <i class="bi bi-plus-lg me-1"></i> Add Product
            </button>
          </div>

          <div class="table-responsive">
            <table class="table admin-table">
              <thead>
                <tr>
                  <th>Product Details</th>
                  <th>Price (₹)</th>
                  <th>Discount</th>
                  <th>Stock Count</th>
                  <th>Stock Status</th>
                  <th>Customer Rating</th>
                  <th class="text-end">Actions</th>
                </tr>
              </thead>
              <tbody id="products-table-body">
                <!-- Rendered dynamically by js/admin.js -->
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- TAB 3: ORDERS MANAGEMENT -->
      <section class="admin-tab-content" id="tab-orders" style="display: none;">
        <div class="admin-panel-card">
          <div class="admin-panel-header">
            <div class="d-flex align-items-center gap-3 flex-wrap">
              <h3 class="admin-panel-title">Customer Orders &amp; Shipments</h3>
              <div class="admin-search-input">
                <i class="bi bi-search"></i>
                <input type="text" id="admin-order-search" placeholder="Search Order ID, Name, Phone...">
              </div>
            </div>
            <div class="btn-group btn-group-sm">
              <button class="btn btn-outline-secondary active" onclick="renderOrdersTable('all')">All</button>
              <button class="btn btn-outline-secondary" onclick="renderOrdersTable('In Transit')">In Transit</button>
              <button class="btn btn-outline-secondary" onclick="renderOrdersTable('Delivered')">Delivered</button>
              <button class="btn btn-outline-secondary" onclick="renderOrdersTable('Processing')">Processing</button>
            </div>
          </div>

          <div class="table-responsive">
            <table class="table admin-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Date Placed</th>
                  <th>Items</th>
                  <th>Total (₹)</th>
                  <th>Status</th>
                  <th class="text-end">Actions</th>
                </tr>
              </thead>
              <tbody id="orders-table-body">
                <!-- Rendered dynamically by js/admin.js -->
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <!-- TAB 4: REVIEWS MANAGEMENT -->
      <section class="admin-tab-content" id="tab-reviews" style="display: none;">
        <div class="admin-panel-card">
          <div class="admin-panel-header">
            <h3 class="admin-panel-title">Customer Testimonials &amp; Reviews</h3>
            <button class="btn btn-primary" onclick="openAddReviewModal()">
              <i class="bi bi-plus-lg me-1"></i> Add Review
            </button>
          </div>

          <div class="table-responsive">
            <table class="table admin-table">
              <thead>
                <tr>
                  <th>Reviewer</th>
                  <th>Rating &amp; Feedback</th>
                  <th>Formulation</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th class="text-end">Actions</th>
                </tr>
              </thead>
              <tbody id="reviews-table-body">
                <!-- Rendered dynamically by js/admin.js -->
              </tbody>
            </table>
          </div>
        </div>
      </section>

    </div>
  </main>

  <!-- MODAL 1: ADD / EDIT PRODUCT MODAL -->
  <div class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
      <div class="modal-content border-0 shadow-lg rounded-3">
        <div class="modal-header text-white" style="background-color: #061E43 !important;">
          <h5 class="modal-title fw-bold" id="product-modal-title">Product Details</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="product-form" onsubmit="handleProductFormSubmit(event)">
          <div class="modal-body p-4">
            <input type="hidden" id="edit-product-id">

            <div class="row g-3">
              <div class="col-md-8">
                <label class="form-label fw-bold small">Product Title</label>
                <input type="text" class="form-control" id="prod-name" placeholder="e.g. Power Veda Ashwagandha Gold KSM-66" required>
              </div>
              <div class="col-md-4">
                <label class="form-label fw-bold small">Product Badge</label>
                <input type="text" class="form-control" id="prod-badge" placeholder="e.g. NATURAL, 100% PURE" value="NATURAL">
              </div>

              <div class="col-md-4">
                <label class="form-label fw-bold small">Discounted Price (₹)</label>
                <input type="number" class="form-control" id="prod-price" placeholder="1499" required min="1">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-bold small">Original Price (₹)</label>
                <input type="number" class="form-control" id="prod-original-price" placeholder="1999" required min="1">
              </div>
              <div class="col-md-4">
                <label class="form-label fw-bold small">Discount Label</label>
                <input type="text" class="form-control" id="prod-discount" placeholder="25% OFF" value="25% OFF">
              </div>

              <div class="col-md-4">
                <label class="form-label fw-bold small">Stock Quantity</label>
                <input type="number" class="form-control" id="prod-stock" placeholder="50" value="50" min="0">
              </div>
              <div class="col-md-8">
                <label class="form-label fw-bold small">Image File Path</label>
                <input type="text" class="form-control" id="prod-image" placeholder="image/products/product-1.jpg" value="image/products/product-1.jpg">
              </div>

              <div class="col-12">
                <label class="form-label fw-bold small">Formulation Description</label>
                <textarea class="form-control" id="prod-desc" rows="3" placeholder="Describe the therapeutic benefits and Ayurvedic ingredients..."></textarea>
              </div>

              <div class="col-12">
                <label class="form-label fw-bold small">Preview Thumbnail</label>
                <div>
                  <img id="prod-img-preview" src="<?php echo e(asset('image/products/product-1.jpg')); ?>" alt="Preview" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 1px solid #E5E7EB;">
                </div>
              </div>
            </div>

          </div>
          <div class="modal-footer bg-light">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4">Save Product</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- MODAL 2: VIEW ORDER DETAILS MODAL -->
  <div class="modal fade" id="viewOrderModal" tabindex="-1" aria-labelledby="viewOrderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg rounded-3">
        <div class="modal-header text-white" style="background-color: #061E43 !important;">
          <h5 class="modal-title fw-bold" id="viewOrderModalLabel">Order Information</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
          <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
            <div>
              <span class="text-muted small">Order ID:</span>
              <h5 class="fw-bold mb-0" id="view-order-id" style="color: #061E43;">#PV-00000</h5>
            </div>
            <span class="badge bg-primary px-3 py-2" id="view-order-status-badge">Delivered</span>
          </div>

          <div class="mb-3">
            <span class="text-muted small d-block">Customer Details:</span>
            <strong id="view-order-customer" class="d-block">Customer Name</strong>
            <span id="view-order-email" class="small text-muted d-block">customer@example.com</span>
            <span id="view-order-address" class="small text-muted d-block mt-1">Delivery Address</span>
          </div>

          <div class="mb-3">
            <span class="text-muted small d-block mb-2">Purchased Formulations:</span>
            <div id="view-order-items-list">
              <!-- Rendered dynamically -->
            </div>
          </div>

          <div class="d-flex justify-content-between align-items-center pt-2">
            <div>
              <span class="text-muted small">Payment Mode:</span>
              <span class="fw-bold d-block small" id="view-order-payment">Prepaid UPI</span>
            </div>
            <div class="text-end">
              <span class="text-muted small">Total Paid:</span>
              <h4 class="fw-bold mb-0" id="view-order-total" style="color: #061E43;">₹0</h4>
            </div>
          </div>

        </div>
        <div class="modal-footer bg-light">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <!-- MODAL 3: ADD REVIEW MODAL -->
  <div class="modal fade" id="reviewModal" tabindex="-1" aria-labelledby="reviewModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content border-0 shadow-lg rounded-3">
        <div class="modal-header text-white" style="background-color: #061E43 !important;">
          <h5 class="modal-title fw-bold" id="reviewModalLabel">Add Verified Customer Review</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="review-form" onsubmit="handleReviewFormSubmit(event)">
          <div class="modal-body p-4">
            <div class="mb-3">
              <label class="form-label fw-bold small">Customer Name</label>
              <input type="text" class="form-control" id="rev-author" placeholder="e.g. Meera Joshi" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold small">City / Location</label>
              <input type="text" class="form-control" id="rev-location" placeholder="e.g. Pune, Maharashtra" required>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold small">Product</label>
              <select class="form-select" id="rev-product">
                <option value="Power Veda Ashwagandha Gold KSM-66">Power Veda Ashwagandha Gold KSM-66</option>
                <option value="Power Veda 24K Saffron Radiance Elixir">Power Veda 24K Saffron Radiance Elixir</option>
                <option value="Power Veda Himalayan Detox Elixir">Power Veda Himalayan Detox Elixir</option>
                <option value="Power Veda Turmeric Curcumin 95%">Power Veda Turmeric Curcumin 95%</option>
                <option value="Power Veda Brahmi Mind Focus Tonic">Power Veda Brahmi Mind Focus Tonic</option>
                <option value="Power Veda Triphala Gut Vitality">Power Veda Triphala Gut Vitality</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold small">Star Rating</label>
              <select class="form-select" id="rev-rating">
                <option value="5">⭐⭐⭐⭐⭐ (5 Stars - Exceptional)</option>
                <option value="4">⭐⭐⭐⭐ (4 Stars - Very Good)</option>
                <option value="3">⭐⭐⭐ (3 Stars - Average)</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label fw-bold small">Customer Feedback &amp; Review</label>
              <textarea class="form-control" id="rev-comment" rows="3" placeholder="Enter customer quote..." required></textarea>
            </div>
          </div>
          <div class="modal-footer bg-light">
            <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary px-4">Publish Review</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Toast Notification Container -->
  <div class="toast-container-custom" id="toast-container" aria-live="polite" aria-atomic="true"></div>

  <!-- Bootstrap Bundle JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <!-- Admin Script -->
  <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\flipcode-new\html\powerveda\powerveda\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>