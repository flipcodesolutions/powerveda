<?php

namespace App\Http\Controllers\Visitor;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PageController extends Controller
{
    /**
     * Display the Power Veda Storefront Home page with database products and reviews.
     */
    public function home(): View
    {
        $products = Product::latest()->get();
        $latestProduct = $products->first();
        $reviews = Review::with('product')->where('status', 'Approved')->latest()->get();

        return view('visitor.pages.home', compact('products', 'latestProduct', 'reviews'));
    }

    /**
     * Display the Privacy Policy page.
     */
    public function privacy(): View
    {
        return view('visitor.pages.privacy');
    }

    /**
     * Display the Terms & Conditions page.
     */
    public function terms(): View
    {
        return view('visitor.pages.terms');
    }

    /**
     * Display the Refund & Return Policy page.
     */
    public function refund(): View
    {
        return view('visitor.pages.refund');
    }
}
