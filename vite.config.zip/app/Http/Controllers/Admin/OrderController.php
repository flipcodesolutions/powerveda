<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\View\View;

class OrderController extends Controller
{
    /**
     * Display the Admin Customer Orders management page.
     */
    public function index(): View
    {
        return view('admin.pages.orders');
    }
}
