<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use App\Models\Product;
use App\Models\Review;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    /**
     * Display the Admin Dashboard Overview.
     */
    public function index(): View
    {
        $productsCount = Product::count();
        $reviewsCount = Review::count();
        $contactsCount = Contact::count();
        $unreadContactsCount = Contact::where('status', 'Unread')->count();
        $recentProducts = Product::latest()->take(5)->get();
        $recentContacts = Contact::latest()->take(5)->get();

        return view('admin.pages.dashboard', compact(
            'productsCount',
            'reviewsCount',
            'contactsCount',
            'unreadContactsCount',
            'recentProducts',
            'recentContacts'
        ));
    }
}
