<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class ProductController extends Controller
{
    /**
     * 1. Display list of all products (READ)
     */
    public function index(): View
    {
        $products = Product::latest()->get();
        return view('admin.pages.products.index', compact('products'));
    }

    /**
     * 2. Show form to create a new product (CREATE)
     */
    public function create(): View
    {
        return view('admin.pages.products.create');
    }

    /**
     * 3. Save new product in database with file upload (STORE)
     */
    public function store(Request $request): RedirectResponse
    {
        // Simple Form Validation
        $request->validate([
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'photo'       => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'detail'      => 'nullable|string',
            'meta_title'  => 'nullable|string|max:255',
            'meta_detail' => 'nullable|string',
            'og_image'    => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $data = [
            'name'        => $request->name,
            'price'       => $request->price,
            'stock'       => $request->stock,
            'detail'      => $request->detail,
            'meta_title'  => $request->filled('meta_title') ? $request->meta_title : $request->name,
            'meta_detail' => $request->filled('meta_detail') ? $request->meta_detail : $request->detail,
            'badge'       => 'NATURAL',
        ];

        // 1. Upload Product Photo
        if ($request->hasFile('photo')) {
            $data['photo'] = $request->file('photo')->store('products/photos', 'public');
        }

        // 2. Upload OG Social Image (if not uploaded, use the same product photo)
        if ($request->hasFile('og_image')) {
            $data['og_image'] = $request->file('og_image')->store('products/og_images', 'public');
        } elseif (isset($data['photo'])) {
            $data['og_image'] = $data['photo'];
        }

        // Create product record in database
        Product::create($data);

        return redirect()->route('admin.products.index')->with('success', 'Product created successfully!');
    }

    /**
     * 4. Show form to edit an existing product (EDIT)
     */
    public function edit(Product $product): View
    {
        return view('admin.pages.products.edit', compact('product'));
    }

    /**
     * 5. Update existing product in database (UPDATE)
     */
    public function update(Request $request, Product $product): RedirectResponse
    {
        // Simple Form Validation
        $request->validate([
            'name'        => 'required|string|max:255',
            'price'       => 'required|numeric|min:0',
            'stock'       => 'required|integer|min:0',
            'photo'       => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'detail'      => 'nullable|string',
            'meta_title'  => 'nullable|string|max:255',
            'meta_detail' => 'nullable|string',
            'og_image'    => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        $data = [
            'name'        => $request->name,
            'price'       => $request->price,
            'stock'       => $request->stock,
            'detail'      => $request->detail,
            'meta_title'  => $request->meta_title,
            'meta_detail' => $request->meta_detail,
        ];

        // 1. If new Photo uploaded, delete old one and store new one
        if ($request->hasFile('photo')) {
            if ($product->photo && Storage::disk('public')->exists($product->photo)) {
                Storage::disk('public')->delete($product->photo);
            }
            $data['photo'] = $request->file('photo')->store('products/photos', 'public');
        }

        // 2. If new OG Image uploaded, delete old one and store new one
        if ($request->hasFile('og_image')) {
            if ($product->og_image && Storage::disk('public')->exists($product->og_image)) {
                Storage::disk('public')->delete($product->og_image);
            }
            $data['og_image'] = $request->file('og_image')->store('products/og_images', 'public');
        }

        // Update product in database
        $product->update($data);

        return redirect()->route('admin.products.index')->with('success', 'Product updated successfully!');
    }

    /**
     * 6. Delete a product from database and remove image files (DELETE)
     */
    public function destroy(Product $product): RedirectResponse
    {
        // Delete image files from storage if present
        if ($product->photo && Storage::disk('public')->exists($product->photo)) {
            Storage::disk('public')->delete($product->photo);
        }

        if ($product->og_image && Storage::disk('public')->exists($product->og_image)) {
            Storage::disk('public')->delete($product->og_image);
        }

        // Delete from database
        $product->delete();

        return redirect()->route('admin.products.index')->with('success', 'Product deleted successfully!');
    }
}
