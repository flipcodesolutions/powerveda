<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'products';

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'price',
        'photo',
        'stock',
        'detail',
        'meta_title',
        'meta_detail',
        'og_image',
        'badge',
        'original_price',
        'discount',
        'rating',
        'reviews_count',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'price' => 'decimal:2',
        'original_price' => 'decimal:2',
        'stock' => 'integer',
        'rating' => 'decimal:1',
        'reviews_count' => 'integer',
    ];

    /**
     * Get the resolved URL for the product photo.
     */
    public function getPhotoUrlAttribute(): string
    {
        if (empty($this->photo)) {
            return asset('image/products/product-1.jpg');
        }

        // If path begins with http/https
        if (str_starts_with($this->photo, 'http://') || str_starts_with($this->photo, 'https://')) {
            return $this->photo;
        }

        // If stored in storage/
        if (str_starts_with($this->photo, 'products/') || str_starts_with($this->photo, 'photos/')) {
            return asset('storage/' . $this->photo);
        }

        return asset($this->photo);
    }

    /**
     * Get the resolved URL for the OG Image.
     */
    public function getOgImageUrlAttribute(): ?string
    {
        if (empty($this->og_image)) {
            return $this->photo_url;
        }

        if (str_starts_with($this->og_image, 'http://') || str_starts_with($this->og_image, 'https://')) {
            return $this->og_image;
        }

        if (str_starts_with($this->og_image, 'products/') || str_starts_with($this->og_image, 'og_images/')) {
            return asset('storage/' . $this->og_image);
        }

        return asset($this->og_image);
    }

    /**
     * Determine stock status label.
     */
    public function getStockStatusAttribute(): string
    {
        if ($this->stock <= 0) {
            return 'Out of Stock';
        }
        if ($this->stock <= 20) {
            return 'Low Stock';
        }
        return 'In Stock';
    }

    /**
     * Relationship: A product has many customer reviews.
     */
    public function reviews(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(Review::class);
    }
}
