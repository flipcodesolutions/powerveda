<?php

namespace Database\Factories;

use App\Models\Contact;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Contact>
 */
class ContactFactory extends Factory
{
    protected $model = Contact::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name'      => fake()->name(),
            'email'     => fake()->safeEmail(),
            'contactno' => fake()->phoneNumber(),
            'subject'   => fake()->sentence(4),
            'messages'  => fake()->paragraph(3),
            'status'    => 'Unread',
        ];
    }
}
