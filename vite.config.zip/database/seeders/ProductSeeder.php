<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $products = [
            [
                'name' => 'Power Veda Ashwagandha Gold KSM-66',
                'price' => 1499.00,
                'original_price' => 1999.00,
                'discount' => '25% OFF',
                'stock' => 85,
                'photo' => 'image/products/product-1.jpg',
                'badge' => 'NATURAL',
                'detail' => 'Premium full-spectrum organic root extract designed to boost physical vitality, reduce stress, and enhance muscle endurance. Enhanced with BioPerine for maximum bioavailability.',
                'meta_title' => 'Buy Organic Ashwagandha Gold KSM-66 | Power Veda Strength',
                'meta_detail' => 'Pure Ayurvedic KSM-66 Ashwagandha extract with standard 5% withanolides for peak stamina, stress relief, and hormonal vitality.',
                'og_image' => 'image/products/product-1.jpg',
                'rating' => 5.0,
                'reviews_count' => 240,
            ],
            [
                'name' => 'Power Veda Himalayan Detox Elixir',
                'price' => 899.00,
                'original_price' => 1199.00,
                'discount' => '25% OFF',
                'stock' => 42,
                'photo' => 'image/products/product-2.jpg',
                'badge' => '100% PURE',
                'detail' => 'Handcrafted botanical blend of holy tulsi, lemongrass, and antioxidant herbs for cellular rejuvenation and daily detox.',
                'meta_title' => 'Himalayan Herbal Detox Elixir Tea | Power Veda Wellness',
                'meta_detail' => 'Purifying whole-body detox infusion formulated from pure Himalayan herbs for liver wellness and gut harmony.',
                'og_image' => 'image/products/product-2.jpg',
                'rating' => 4.8,
                'reviews_count' => 135,
            ],
            [
                'name' => 'Power Veda 24K Saffron Radiance Elixir',
                'price' => 2499.00,
                'original_price' => 3299.00,
                'discount' => '24% OFF',
                'stock' => 18,
                'photo' => 'image/products/product-3.jpg',
                'badge' => 'PREMIUM',
                'detail' => 'Sacred facial and skin radiance elixir formulated with pure Kashmiri saffron, sandalwood, and lotus blossoms.',
                'meta_title' => 'Kumkumadi 24K Saffron Face Elixir | Power Veda Ayurveda',
                'meta_detail' => 'Luxury Ayurvedic facial oil with authentic Kashmiri saffron and 24K gold essence for radiant, luminous skin.',
                'og_image' => 'image/products/product-3.jpg',
                'rating' => 5.0,
                'reviews_count' => 310,
            ],
            [
                'name' => 'Power Veda Triphala Gut Vitality',
                'price' => 799.00,
                'original_price' => 999.00,
                'discount' => '20% OFF',
                'stock' => 94,
                'photo' => 'image/products/product-4.jpg',
                'badge' => 'VITALITY',
                'detail' => 'Time-tested three-fruit botanical formula supporting digestion, nutrient absorption, and body purification.',
                'meta_title' => 'Organic Triphala Gut Cleanse & Digestion | Power Veda',
                'meta_detail' => 'Traditional Haritaki, Bibhitaki, and Amalaki formulation for optimal digestive balance and gentle overnight detox.',
                'og_image' => 'image/products/product-4.jpg',
                'rating' => 4.7,
                'reviews_count' => 95,
            ],
            [
                'name' => 'Power Veda Brahmi Mind Focus Tonic',
                'price' => 1199.00,
                'original_price' => 1599.00,
                'discount' => '25% OFF',
                'stock' => 60,
                'photo' => 'image/products/product-5.jpg',
                'badge' => 'STRENGTH',
                'detail' => 'Cognitive enhancement formulation supporting peak memory clarity, sharp focus, and nervous system health.',
                'meta_title' => 'Brahmi Mind Memory & Focus Formulation | Power Veda',
                'meta_detail' => 'Ayurvedic nootropic tonic with pure Bacopa Monnieri for enhanced cognitive power and serene mental clarity.',
                'og_image' => 'image/products/product-5.jpg',
                'rating' => 4.9,
                'reviews_count' => 160,
            ],
            [
                'name' => 'Power Veda Turmeric Curcumin 95%',
                'price' => 1299.00,
                'original_price' => 1699.00,
                'discount' => '23% OFF',
                'stock' => 75,
                'photo' => 'image/products/product-6.jpg',
                'badge' => 'IMMUNITY',
                'detail' => 'Ultra-potent golden turmeric extract formulated with BioPerine for joint flexibility, vitality, and robust immunity.',
                'meta_title' => 'Pure Curcumin 95% Joint & Immune Support | Power Veda',
                'meta_detail' => 'Standardized 95% curcuminoids extract for healthy inflammatory response and joint comfort.',
                'og_image' => 'image/products/product-6.jpg',
                'rating' => 4.9,
                'reviews_count' => 215,
            ],
            [
                'name' => 'Power Veda Neem & Tulsi Purifying Cleanse',
                'price' => 699.00,
                'original_price' => 899.00,
                'discount' => '22% OFF',
                'stock' => 50,
                'photo' => 'image/products/product-7.jpg',
                'badge' => 'WELLNESS',
                'detail' => 'Gentle soap-free foaming wash that balances natural skin oils and deeply purifies pores with sacred botanicals.',
                'meta_title' => 'Neem & Tulsi Herbal Clarifying Face Wash | Power Veda',
                'meta_detail' => 'Antibacterial botanical face wash enriched with organic Neem and holy Tulsi for blemish-free skin.',
                'og_image' => 'image/products/product-7.jpg',
                'rating' => 4.8,
                'reviews_count' => 112,
            ],
            [
                'name' => 'Power Veda Cold-Pressed Sweet Almond Oil',
                'price' => 999.00,
                'original_price' => 1299.00,
                'discount' => '23% OFF',
                'stock' => 35,
                'photo' => 'image/products/product-8.jpg',
                'badge' => 'COLD PRESSED',
                'detail' => '100% unrefined therapeutic oil rich in natural Vitamin E, perfect for restorative body massage and muscle recovery.',
                'meta_title' => '100% Pure Cold-Pressed Sweet Almond Oil | Power Veda',
                'meta_detail' => 'Virgin almond oil for deep skin nourishment, hair vitality, and therapeutic Abhyanga body massage.',
                'og_image' => 'image/products/product-8.jpg',
                'rating' => 4.9,
                'reviews_count' => 180,
            ],
        ];

        foreach ($products as $data) {
            Product::create($data);
        }
    }
}
