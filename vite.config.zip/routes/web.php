<?php

use App\Http\Controllers\Admin\AuthController as AdminAuthController;
use App\Http\Controllers\Admin\ContactController as AdminContactController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ReviewController;
use App\Http\Controllers\Visitor\ContactController as VisitorContactController;
use App\Http\Controllers\Visitor\PageController;
use App\Http\Controllers\Visitor\UserAuthController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes - Power Veda
|--------------------------------------------------------------------------
*/

// Visitor Frontend Routes
Route::get('/', [PageController::class, 'home'])->name('home');
Route::get('/privacy-policy', [PageController::class, 'privacy'])->name('privacy');
Route::get('/terms-and-conditions', [PageController::class, 'terms'])->name('terms');
Route::get('/refund-policy', [PageController::class, 'refund'])->name('refund');

// Visitor Contact Form Submission
Route::post('/contact', [VisitorContactController::class, 'submit'])->name('contact.submit');

// Storefront User Authentication Routes (Visitor/Customer)
Route::post('/register', [UserAuthController::class, 'register'])->name('register');
Route::post('/login', [UserAuthController::class, 'login'])->name('login');
Route::post('/logout', [UserAuthController::class, 'logout'])->name('logout');
Route::get('/user/me', [UserAuthController::class, 'me'])->name('user.me');

// Friendly Redirects
Route::redirect('/privacy', '/privacy-policy');
Route::redirect('/terms', '/terms-and-conditions');
Route::redirect('/refund', '/refund-policy');

// Admin Authentication Routes
Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('/login', [AdminAuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AdminAuthController::class, 'login'])->name('login.submit');
    Route::post('/logout', [AdminAuthController::class, 'logout'])->name('logout');
});

// Admin Console Protected Routes (Admin Middleware)
Route::prefix('admin')->name('admin.')->middleware(['admin'])->group(function () {
    // Admin Dashboard
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/dashboard', [DashboardController::class, 'index']);

    // Standard Product CRUD Resource
    Route::resource('products', ProductController::class);

    // Orders, Reviews & Contacts Management
    Route::get('/orders', [OrderController::class, 'index'])->name('orders');
    Route::resource('reviews', ReviewController::class);

    // Contact Inquiries Management
    Route::get('/contacts', [AdminContactController::class, 'index'])->name('contacts.index');
    Route::get('/contacts/{contact}', [AdminContactController::class, 'show'])->name('contacts.show');
    Route::patch('/contacts/{contact}/status', [AdminContactController::class, 'updateStatus'])->name('contacts.status');
    Route::delete('/contacts/{contact}', [AdminContactController::class, 'destroy'])->name('contacts.destroy');
});
